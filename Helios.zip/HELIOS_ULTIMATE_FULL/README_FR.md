# HELIOS ULTIMATE FULL

**Projet modulaire d'assistant personnel Android + tableau de bord web + serveur facultatif.**

Cette archive fournit une base de projet réelle à développer et à tester. Ce n'est pas encore un Jarvis de film terminé : les fonctions qui dépendent d'un modèle IA, d'un service tiers, d'un appareil domotique, d'une autorisation Android spéciale ou d'un développement complémentaire sont clairement signalées dans l'application et dans la feuille de route.

## Contenu de l'archive

```text
HELIOS_ULTIMATE_FULL/
├── android/                 Application Android native en Java
├── web/                     Tableau de bord web installable (PWA) et hors ligne
├── server/                  API PHP pour IA et synchronisation MySQL
├── modules/                 Contrat et exemple d'extension
├── docs/                    Sécurité et feuille de route
└── .github/workflows/       Construction APK par GitHub Actions
```

## 1. Fonctions réellement présentes dans cette base

### Application Android

- Interface HELIOS sombre, tableau de commande et catalogue des modules.
- Reconnaissance vocale à la demande en français via le service vocal Android, avec préférence hors ligne quand le pack français du téléphone est installé.
- Mot d'activation « HELIOS » détecté localement par Sherpa-ONNX/KWS après génération de l'APK par GitHub Actions. Le microphone reste actif dans un service Android de premier plan avec notification visible.
- Synthèse vocale française. La voix masculine dépend des voix installées et proposées par le moteur vocal du téléphone.
- Commandes locales : salutation, heure, date, état de la batterie, notes, tâches et minuteurs Android.
- Ouverture directe des paramètres Wi-Fi et Bluetooth, et préparation d’événements dans le calendrier.
- Ouverture d'applications visibles par Android, WhatsApp, YouTube, appareil photo, paramètres et calendrier.
- Navigation et commandes locales façon Voice Access par le service d'accessibilité HELIOS : retour, accueil, notifications, paramètres rapides, applications récentes, clic sur un libellé visible et défilement.
- Préparation d'un appel dans le composeur, d'un SMS dans l'application SMS et d'une recherche web. L'utilisateur confirme lui-même l'appel ou l'envoi.
- Mode urgence qui ouvre le composeur sans appeler automatiquement un numéro.
- Mémoire locale des notes et tâches.
- Connexion facultative au serveur PHP avec Gemini via API HTTPS (la clé reste sur le serveur) ; l'assistant local continue à fonctionner sans Internet.
- Synchronisation additive des notes et tâches avec le serveur lorsque celui-ci est installé.
- Service optionnel de notifications, à autoriser manuellement. Dans cette base, il ne stocke pas le texte des notifications.

### Tableau web

- Interface utilisable sur téléphone, tablette et ordinateur.
- Application web installable (PWA) et cache du shell pour le mode hors ligne.
- Notes, tâches, compteurs et export de sauvegarde JSON.
- Reconnaissance vocale via navigateur lorsque le navigateur la propose.
- Connexion facultative au moteur IA et synchronisation avec le serveur PHP.

### Serveur

- Endpoint de santé (`api/health.php`).
- Endpoint de conversation IA (`api/assistant.php`) pour Gemini `generateContent`, avec option de fournisseur OpenAI-compatible historique.
- Endpoint de synchronisation (`api/sync.php`) avec stockage MySQL/MariaDB.
- Jeton serveur et clé IA configurés côté serveur, pas dans le code de l'APK.

## 2. Fonctions prévues mais pas encore terminées

Les modules vision/OCR, reconnaissance d'objets, biométrie, domotique complète, lecture avancée des notifications, automatisations multi-étapes, traduction hors ligne, calendrier intelligent, mode urgence enrichi, assistant financier avancé et analyse d'images par IA sont répertoriés dans l'architecture, mais ne sont pas encore des fonctions opérationnelles complètes. Le mot « HELIOS » est maintenant intégré en détection locale Sherpa-ONNX ; la robustesse avec l'accent français doit être testée sur le téléphone. La commande qui suit le réveil utilise le moteur vocal Android et dépend de son pack français hors ligne.

Le système Android interdit aussi certaines actions sans autorisation spéciale ou sans rôle d'application par défaut. HELIOS ne peut pas honnêtement promettre le contrôle illimité du téléphone. Voir `docs/SECURITY_FR.md`.

## 3. Installation sur Android

### Important pour votre environnement KSweb

KSweb est utile pour héberger localement les fichiers web et, selon sa configuration, exécuter le serveur PHP/MySQL. **KSweb ne compile pas directement une application Android APK.** Le dossier `android/` est un vrai projet Android natif qui doit être compilé avec Android Studio ou par une chaîne de compilation distante comme GitHub Actions.

### Tester le tableau web avec KSweb

1. Décompressez l'archive.
2. Copiez le dossier `web` dans le dossier servi par KSweb, par exemple `htdocs/helios`.
3. Démarrez le serveur web dans KSweb.
4. Ouvrez dans Chrome l'adresse locale indiquée par KSweb, en ajoutant `/helios/`.
5. Ajoutez HELIOS à l'écran d'accueil depuis le menu de Chrome si l'option est proposée.
6. Ouvrez HELIOS une première fois avec Internet ou le serveur local actif pour que le navigateur mette en cache les fichiers de l'application.

Le port exact dépend de la configuration KSweb. Les données locales du tableau web sont stockées dans le navigateur de cet appareil.

### Générer le fichier APK

**Méthode Android Studio :**

1. Ouvrez le dossier `android/` dans Android Studio sur un ordinateur.
2. Installez le JDK 17 et le SDK Android API 37 lorsque l'IDE le demande.
3. Laissez Gradle synchroniser le projet.
4. Lancez **Build → Build APK(s)**.
5. Le fichier de débogage sera généré dans `android/app/build/outputs/apk/debug/`.

**Méthode GitHub Actions sans ordinateur personnel :**

1. Créez un dépôt GitHub vide depuis le navigateur de votre téléphone.
2. Téléversez le ZIP fourni sous le nom exact `HELIOS_ULTIMATE_FULL.zip` à la racine du dépôt, en remplaçant l'ancien fichier du même nom.
3. Envoyez ce changement sur la branche `main`.
4. Ouvrez l'onglet **Actions** du dépôt et lancez **Build HELIOS Android APK** si le workflow ne démarre pas automatiquement.
5. Le workflow télécharge le modèle Sherpa-ONNX officiel, crée `keywords.txt`, compile l'application et publie `HELIOS-ULTIMATE-FULL-debug-apk`.
6. Téléchargez l'artefact APK depuis l'exécution réussie et installez-le sur le téléphone. Android peut demander d'autoriser l'installation depuis le navigateur ou le gestionnaire de fichiers.

Le ZIP est léger et ne contient pas les fichiers ONNX du modèle : GitHub Actions les télécharge pendant le build. Cette étape, le SDK et les dépendances nécessitent Internet pendant la compilation. Aucun APK précompilé n'est inclus.

## 4. Activer la conversation intelligente

La conversation avancée nécessite un serveur accessible en HTTPS et un fournisseur IA compatible. Elle n'est pas gratuite par défaut : le fournisseur peut facturer les requêtes.

1. Installez `server/` sur un hébergement PHP avec HTTPS.
2. Suivez `server/README_FR.md`.
3. Créez `server/config.php` depuis `config.example.php`.
4. Configurez le jeton serveur, puis sur l'hébergement définissez `HELIOS_AI_PROVIDER=gemini`, `HELIOS_GEMINI_KEY` et `HELIOS_GEMINI_MODEL=gemini-3.5-flash-lite` (ou un modèle stable actuel compatible). La clé ne doit jamais être placée dans l'APK ou le dépôt public.
5. Dans HELIOS, ouvrez **Configurer le serveur IA / synchronisation**.
6. Saisissez l'adresse complète de `api/assistant.php` et le jeton.

Sans serveur ou sans clé IA, HELIOS continue à exécuter les commandes locales disponibles.

## 5. Synchroniser plusieurs appareils

Le tableau web et l'application Android peuvent envoyer les notes et tâches au même serveur avec le même jeton. Le jeton reste stocké en clair dans les préférences locales Android et le stockage local du navigateur dans cette alpha : ne réutilisez pas de jeton administrateur et ne partagez pas l'appareil. L'alpha effectue une **fusion additive** : les éléments distincts sont ajoutés et les doublons textuels sont évités. Les suppressions ne sont pas encore répercutées sur les autres appareils. Faites une sauvegarde avant les tests multi-appareils.

Pour synchroniser tous les appareils, chaque appareil doit accéder au même serveur HTTPS et utiliser le même jeton.

## 6. Ajouter des modules

Consultez `modules/README_FR.md`. Les modules natifs sont enregistrés dans `ModuleRegistry`. Les extensions natives doivent être auditées et intégrées dans une nouvelle version signée de l'application. Le projet ne télécharge pas et n'exécute pas de code Android inconnu à distance.

## 7. Commandes locales Android à essayer

- `Bonjour HELIOS`
- `Quelle heure est-il ?`
- `Quelle date sommes-nous ?`
- `Quel est le niveau de batterie ?`
- `Ouvre Wi-Fi` ou `Ouvre Bluetooth`
- `Minuteur 5 minutes` ou `Minuteur 30 secondes`
- `Événement réunion avec le client` (prépare un événement à vérifier dans le calendrier)
- `Note acheter du pain`
- `Mes notes`
- `Tâche appeler le client`
- `Mes tâches`
- `Ouvre WhatsApp`
- `Ouvre YouTube`
- `Ouvre paramètres`
- `Appareil photo`
- `Appelle 099...` (ouvre le composeur, ne lance pas l'appel)
- `SMS 099...` (ouvre l'application SMS)
- `Recherche développement Android`
- `Retour`, `Accueil`, `Ouvre les notifications`, `Paramètres rapides`
- `Clique sur [libellé visible]`, `Défile vers le bas`, `Défile vers le haut` (accessibilité HELIOS activée)
- `Aide`

La détection du mot « HELIOS » est locale et ne transmet pas le son. Le modèle KWS Sherpa utilisé dans ce build est un modèle anglais/chinois léger ; sa reconnaissance du nom HELIOS prononcé avec l'accent français n'est pas garantie et doit être testée. Après détection, l'utilisateur touche la notification HELIOS ; la reconnaissance de la phrase française est alors effectuée par Android. Elle est hors ligne uniquement si le pack français du moteur vocal est installé sur le téléphone. Si Android ne sait pas reconnaître le français hors ligne, HELIOS peut retenter avec Internet selon le service vocal configuré.

## 8. Vérifications réalisées pour cette archive

- Les fichiers PHP ont été écrits pour PHP 8.1+ et sont destinés à être vérifiés avec `php -l` sur le serveur.
- Le JavaScript du tableau web peut être vérifié avec `node --check app.js`.
- L'environnement de création de cette archive ne dispose pas du SDK Android ni d'Android Gradle Plugin : l'APK n'a donc pas été construit ni testé sur un téléphone dans cette session.

**Version :** 1.4.0-hybrid-sherpa-gemini  
**Langue de l'interface :** français  
**Nom de l'assistant :** HELIOS


## Édition 1.1 — Interface HUD et conversation
- Écran Android redessiné avec un noyau lumineux animé façon interface Jarvis, sans connexion ni images externes.
- Compteurs de notes et tâches, ajout manuel depuis l'écran d'accueil et accès rapide aux listes.
- Les commandes précédées de « Bonjour HELIOS » sont maintenant normalisées avant le traitement (ex. « Bonjour HELIOS, note appeler maman »).
- Conversation continue au premier plan avec relance après la réponse vocale. Android peut interrompre le micro lors d'un appel, d'un changement d'application ou d'une restriction système.
- Les notes et tâches sont conservées localement via les préférences privées Android.

**Limites :** l'écoute du mot HELIOS nécessite une activation manuelle, une notification visible et l'autorisation microphone. Android peut suspendre ou interrompre le service selon ses règles d'économie d'énergie. L'accessibilité doit être activée manuellement dans les paramètres Android et n'offre pas le contrôle complet de toutes les applications : certains boutons, écrans protégés et actions sensibles restent à l'utilisateur. Gemini nécessite un serveur HTTPS configuré, une clé API et Internet ; il ne fonctionne pas hors ligne. Les commandes locales continuent sans Gemini.
