<?php
/**
 * Copy this file to config.php and replace every CHANGE_ME value.
 * Prefer environment variables and keep config.php outside the public web root.
 */
return [
    'api_token' => getenv('HELIOS_API_TOKEN') ?: 'CHANGE_ME_TO_A_LONG_RANDOM_SECRET',
    // Gemini is the default online provider. The key stays on this HTTPS server, never in the APK.
    'ai_provider' => getenv('HELIOS_AI_PROVIDER') ?: 'gemini',
    'gemini_api_key' => getenv('HELIOS_GEMINI_KEY') ?: '',
    'gemini_model' => getenv('HELIOS_GEMINI_MODEL') ?: 'gemini-3.5-flash-lite',
    // Optional legacy OpenAI-compatible provider settings.
    'ai_base_url' => getenv('HELIOS_AI_BASE_URL') ?: '',
    'ai_api_key' => getenv('HELIOS_AI_KEY') ?: '',
    'ai_model' => getenv('HELIOS_AI_MODEL') ?: '',
    'database' => [
        'host' => getenv('HELIOS_DB_HOST') ?: '127.0.0.1',
        'port' => getenv('HELIOS_DB_PORT') ?: '3306',
        'name' => getenv('HELIOS_DB_NAME') ?: 'helios',
        'user' => getenv('HELIOS_DB_USER') ?: 'helios_user',
        'password' => getenv('HELIOS_DB_PASSWORD') ?: '',
        'charset' => 'utf8mb4',
    ],
];
