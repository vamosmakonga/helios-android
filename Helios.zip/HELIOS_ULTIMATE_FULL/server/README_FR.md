# Serveur HELIOS — installation

Le serveur est facultatif. Il relie HELIOS à Gemini (par défaut) ou à un fournisseur OpenAI-compatible, et synchronise les notes/tâches. La clé Gemini reste uniquement sur le serveur.

## Prérequis

- PHP 8.1 ou plus récent (recommandé : 8.2+)
- Extensions PHP `curl`, `pdo`, `pdo_mysql`, `json`, `mbstring`
- MySQL 8 ou MariaDB compatible
- Un hébergement HTTPS
- Une clé Gemini API créée dans Google AI Studio pour la conversation distante (facultatif)

## Mise en place

1. Créez une base de données et importez `database/schema.sql`.
2. Copiez `config.example.php` en `config.php`.
3. Remplacez le jeton `api_token` par une chaîne aléatoire longue (au moins 32 caractères).
4. Renseignez les accès MySQL.
5. Pour Gemini, définissez sur l'hébergement les variables `HELIOS_AI_PROVIDER=gemini`, `HELIOS_GEMINI_KEY` (clé de Google AI Studio) et, facultativement, `HELIOS_GEMINI_MODEL=gemini-3.5-flash-lite`. La valeur par défaut est déjà `gemini-3.5-flash-lite`. Si votre hébergement ne propose pas de variables d'environnement, ajoutez ces trois valeurs uniquement dans `server/config.php` (fichier ignoré par Git). Pour l'ancien fournisseur OpenAI-compatible, utilisez `HELIOS_AI_PROVIDER=openai-compatible`, `HELIOS_AI_BASE_URL`, `HELIOS_AI_KEY` et `HELIOS_AI_MODEL`.
6. Placez le dossier `server` derrière HTTPS. Idéalement, placez `config.php` en dehors du dossier public et adaptez le chemin dans `api/bootstrap.php`.
7. Testez `https://votre-domaine.tld/server/api/health.php`.
8. Dans HELIOS Android ou le tableau web, entrez l'URL complète de `api/assistant.php` et le même jeton serveur.

## Synchronisation web

Le tableau web transforme l'URL `assistant.php` en `sync.php` puis envoie les notes et tâches au serveur. Le serveur stocke une copie complète par jeton. Dans cette version alpha, le serveur ne fusionne pas les modifications concurrentes : une sauvegarde remplace la précédente. Faites un export JSON avant tout test multi-appareils.

## Sécurité

- Ne publiez jamais `config.php` ni la clé Gemini. N'insérez jamais la clé dans le code Android, le ZIP distribué ou les paramètres visibles de l'application.
- La connexion à Gemini utilise une clé d'API privée du serveur, pas la connexion Google personnelle (Gmail) de l'utilisateur. Les appels Gemini nécessitent Internet et peuvent être soumis à des quotas ou à une facturation.
- N'utilisez jamais HTTP public pour transmettre un jeton.
- Ce modèle à jeton partagé est prévu pour un prototype privé. Pour une mise en production multi-utilisateur, ajoutez comptes, jetons individuels révocables, limitation de débit, journalisation minimisée, sauvegardes et règles de rétention.
- Ne connectez pas de fonctions bancaires réelles ni d'actions physiques de serrure à cette première version.
