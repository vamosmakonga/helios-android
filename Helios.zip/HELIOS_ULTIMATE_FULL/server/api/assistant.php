<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') helios_json(['error' => 'Méthode non autorisée.'], 405);
$config = helios_config();
helios_authorize($config);
$body = helios_body(150000);
$message = trim((string)($body['message'] ?? ''));
$history = is_array($body['history'] ?? null) ? $body['history'] : [];
if ($message === '') helios_json(['error' => 'Le message est vide.'], 400);
if (mb_strlen($message, 'UTF-8') > 6000) helios_json(['error' => 'Le message dépasse la limite autorisée.'], 413);
if (!function_exists('curl_init')) helios_json(['error' => 'L’extension PHP cURL est nécessaire pour le moteur IA.'], 503);

$systemPrompt = 'Tu es HELIOS, un assistant personnel francophone. Réponds clairement et honnêtement. Tu ne prétends jamais contrôler le téléphone, accéder à la caméra, aux messages, aux comptes ou aux appareils si aucun outil ne t’a donné cet accès. Pour les actions sensibles, demande une confirmation et rappelle les limites de sécurité.';
$turns = [];
// Keep a short history and merge adjacent turns with the same role. Gemini expects
// alternating user/model contents, including after an interrupted previous request.
foreach (array_slice($history, -20) as $turn) {
    if (!is_array($turn)) continue;
    $role = (string)($turn['role'] ?? '');
    $content = trim((string)($turn['content'] ?? ''));
    if (!in_array($role, ['user', 'assistant'], true) || $content === '' || mb_strlen($content, 'UTF-8') > 6000) continue;
    if (!$turns && $role !== 'user') continue;
    $last = count($turns) - 1;
    if ($last >= 0 && $turns[$last]['role'] === $role) {
        $turns[$last]['content'] = mb_substr($turns[$last]['content'] . "\n" . $content, 0, 6000, 'UTF-8');
    } else {
        $turns[] = ['role' => $role, 'content' => $content];
    }
}
$last = count($turns) - 1;
if ($last >= 0 && $turns[$last]['role'] === 'user') {
    $turns[$last]['content'] = mb_substr($turns[$last]['content'] . "\n" . $message, 0, 6000, 'UTF-8');
} else {
    $turns[] = ['role' => 'user', 'content' => $message];
}
$provider = strtolower(trim((string)($config['ai_provider'] ?? 'gemini')));

if ($provider === 'gemini') {
    $apiKey = trim((string)($config['gemini_api_key'] ?? ''));
    $model = trim((string)($config['gemini_model'] ?? 'gemini-3.5-flash-lite'));
    if ($apiKey === '' || preg_match('/^[A-Za-z0-9._-]+$/', $model) !== 1) {
        helios_json(['error' => 'Gemini n’est pas configuré. Ajoutez HELIOS_GEMINI_KEY et vérifiez HELIOS_GEMINI_MODEL sur le serveur.'], 503);
    }
    $contents = [];
    foreach ($turns as $turn) {
        $contents[] = [
            'role' => $turn['role'] === 'assistant' ? 'model' : 'user',
            'parts' => [['text' => $turn['content']]],
        ];
    }
    $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent';
    $payload = [
        'systemInstruction' => ['parts' => [['text' => $systemPrompt]]],
        'contents' => $contents,
        'generationConfig' => ['temperature' => 0.6],
    ];
    $headers = ['Content-Type: application/json', 'x-goog-api-key: ' . $apiKey];
} elseif ($provider === 'openai-compatible') {
    $apiKey = trim((string)($config['ai_api_key'] ?? ''));
    $model = trim((string)($config['ai_model'] ?? ''));
    $url = trim((string)($config['ai_base_url'] ?? ''));
    if ($apiKey === '' || $model === '' || !filter_var($url, FILTER_VALIDATE_URL) || !str_starts_with($url, 'https://')) {
        helios_json(['error' => 'Le fournisseur OpenAI-compatible n’est pas configuré correctement sur le serveur.'], 503);
    }
    $messages = [['role' => 'system', 'content' => $systemPrompt]];
    foreach ($turns as $turn) $messages[] = $turn;
    $payload = ['model' => $model, 'messages' => $messages, 'temperature' => 0.6];
    $headers = ['Content-Type: application/json', 'Authorization: Bearer ' . $apiKey];
} else {
    helios_json(['error' => 'Fournisseur IA inconnu. Choisissez gemini ou openai-compatible.'], 503);
}

$encodedPayload = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
if ($encodedPayload === false) helios_json(['error' => 'Impossible de préparer la requête IA.'], 500);
$curl = curl_init($url);
curl_setopt_array($curl, [
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 12,
    CURLOPT_TIMEOUT => 50,
    CURLOPT_HTTPHEADER => $headers,
    CURLOPT_POSTFIELDS => $encodedPayload,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_SSL_VERIFYHOST => 2,
]);
$response = curl_exec($curl);
$curlError = curl_error($curl);
$status = (int)curl_getinfo($curl, CURLINFO_HTTP_CODE);
curl_close($curl);
if ($response === false) helios_json(['error' => 'Connexion au fournisseur IA impossible : ' . $curlError], 502);
$decoded = json_decode($response, true);
if ($status < 200 || $status >= 300) {
    $providerMessage = is_array($decoded) ? (string)($decoded['error']['message'] ?? '') : '';
    helios_json(['error' => 'Le fournisseur IA a refusé la requête (HTTP ' . $status . ').' . ($providerMessage !== '' ? ' ' . mb_substr($providerMessage, 0, 220, 'UTF-8') : '')], 502);
}

if ($provider === 'gemini') {
    $parts = $decoded['candidates'][0]['content']['parts'] ?? [];
    $replyParts = [];
    if (is_array($parts)) {
        foreach ($parts as $part) if (isset($part['text']) && is_string($part['text'])) $replyParts[] = $part['text'];
    }
    $reply = trim(implode("\n", $replyParts));
} else {
    $reply = trim((string)($decoded['choices'][0]['message']['content'] ?? ''));
}
if ($reply === '') helios_json(['error' => 'Le fournisseur IA a renvoyé une réponse vide.'], 502);
helios_json(['reply' => $reply]);
