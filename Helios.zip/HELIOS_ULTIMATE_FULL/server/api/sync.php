<?php
declare(strict_types=1);
require __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') helios_json(['error' => 'Méthode non autorisée.'], 405);
$config = helios_config();
$token = helios_authorize($config);
$body = helios_body(1000000);
$data = $body['data'] ?? null;
if (!is_array($data) || !isset($data['notes'], $data['tasks']) || !is_array($data['notes']) || !is_array($data['tasks'])) {
    helios_json(['error' => 'Format de synchronisation invalide.'], 400);
}
if (count($data['notes']) > 5000 || count($data['tasks']) > 5000) helios_json(['error' => 'Trop d’éléments à synchroniser.'], 413);

$pdo = helios_pdo($config);
$accountId = hash('sha256', $token);
$read = $pdo->prepare('SELECT data_json FROM helios_sync WHERE account_id = :account_id LIMIT 1');
$read->execute(['account_id' => $accountId]);
$existingJson = $read->fetchColumn();
$existing = is_string($existingJson) ? json_decode($existingJson, true) : [];
if (!is_array($existing)) $existing = [];

// Alpha sync strategy: additive merge. Deletions are not propagated in this version.
$merged = [];
foreach (['notes', 'tasks'] as $listName) {
    $combined = array_merge(
        is_array($existing[$listName] ?? null) ? $existing[$listName] : [],
        $data[$listName]
    );
    $unique = [];
    $seen = [];
    foreach ($combined as $item) {
        if (!is_string($item)) continue;
        $clean = trim($item);
        if ($clean === '' || isset($seen[$clean])) continue;
        $seen[$clean] = true;
        $unique[] = $clean;
    }
    $merged[$listName] = array_slice($unique, -5000);
}
$json = json_encode($merged, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$stmt = $pdo->prepare('INSERT INTO helios_sync (account_id, data_json, updated_at) VALUES (:account_id, :data_json, UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE data_json = VALUES(data_json), updated_at = UTC_TIMESTAMP()');
$stmt->execute(['account_id' => $accountId, 'data_json' => $json]);
helios_json(['status' => 'synced', 'data' => $merged, 'updated_at' => gmdate('c')]);
