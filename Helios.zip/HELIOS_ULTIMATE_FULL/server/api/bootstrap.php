<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store');

function helios_json(array $payload, int $status = 200): void {
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function helios_config(): array {
    $path = dirname(__DIR__) . '/config.php';
    if (!is_file($path)) helios_json(['error' => 'Serveur non configuré : créez server/config.php.'], 503);
    $config = require $path;
    return is_array($config) ? $config : [];
}

function helios_bearer(): string {
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (!$header && function_exists('getallheaders')) {
        $headers = getallheaders();
        $header = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    }
    return preg_match('/^Bearer\s+(.+)$/i', trim($header), $matches) ? trim($matches[1]) : '';
}

function helios_authorize(array $config): string {
    $expected = (string)($config['api_token'] ?? '');
    $provided = helios_bearer();
    if ($expected === '' || str_starts_with($expected, 'CHANGE_ME') || $provided === '' || !hash_equals($expected, $provided)) {
        helios_json(['error' => 'Accès refusé. Vérifiez le jeton HELIOS.'], 401);
    }
    return $provided;
}

function helios_body(int $maxBytes = 1000000): array {
    $raw = file_get_contents('php://input');
    if ($raw === false || strlen($raw) > $maxBytes) helios_json(['error' => 'Corps de requête trop volumineux ou illisible.'], 413);
    $data = json_decode($raw, true);
    if (!is_array($data)) helios_json(['error' => 'JSON invalide.'], 400);
    return $data;
}

function helios_pdo(array $config): PDO {
    $db = $config['database'] ?? [];
    $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=%s',
        $db['host'] ?? '127.0.0.1', $db['port'] ?? '3306', $db['name'] ?? 'helios', $db['charset'] ?? 'utf8mb4');
    try {
        return new PDO($dsn, (string)($db['user'] ?? ''), (string)($db['password'] ?? ''), [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    } catch (Throwable $exception) {
        helios_json(['error' => 'Base de données indisponible. Vérifiez les paramètres MySQL du serveur.'], 503);
    }
}
