CREATE DATABASE IF NOT EXISTS helios CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE helios;

CREATE TABLE IF NOT EXISTS helios_sync (
    account_id CHAR(64) NOT NULL,
    data_json LONGTEXT NOT NULL,
    updated_at DATETIME NOT NULL,
    PRIMARY KEY (account_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
