# Correctif conversation vocale et mémoire locale

## Conversation continue
Dans l'application, appuyez sur « Conversation continue : désactivée ». HELIOS démarre l'écoute. Après chaque réponse vocale, il relance automatiquement la reconnaissance. Appuyez sur « Arrêter la conversation continue » pour couper le micro.

Cette écoute continue reste active uniquement tant que l'écran HELIOS est ouvert et que le mode est activé. Android peut interrompre la reconnaissance lorsque l'application passe en arrière-plan ou lorsque le service vocal s'arrête. Ce correctif ne prétend pas fournir un mot de réveil permanent.

## Notes et tâches
Commandes reconnues :
- « note acheter du pain »
- « prends note appeler maman »
- « ajoute une note réunion vendredi »
- « tâche finir le devoir »
- « ajoute une tâche étudier Java »
- « crée une tâche payer la facture »
- « rappelle-moi de vérifier le téléphone »

Les éléments sont stockés localement dans les préférences privées de l'application. Les listes restent vides tant qu'aucune commande de création n'a été enregistrée. Ouvrez « Mes notes » et « Mes tâches » pour les consulter.
