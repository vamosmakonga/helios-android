# Feuille de route HELIOS

## Niveau 1 — Base fonctionnelle incluse

- Application Android native avec interface HELIOS.
- Commande vocale à la demande en français, si un service vocal est disponible.
- Synthèse vocale française avec la voix fournie par le moteur Android.
- Commandes locales : heure, date, notes, tâches, ouvrir certaines applications, paramètres, appareil photo, composeur, SMS préparé, recherche web et alarmes.
- Mémoire locale des notes, tâches et dernières commandes.
- Tableau web installable avec stockage hors ligne.
- API PHP pour conversation IA et synchronisation additive.
- Contrats et registre de modules.

## Niveau 2 — Intégrations à développer et tester

- Détection locale du mot « HELIOS » ajoutée en version 1.4.0 ; restent à valider la robustesse avec l’accent local, l’optimisation batterie et la compatibilité de chaque constructeur.
- Voix masculine sélectionnable parmi les voix réellement installées sur le téléphone.
- Biométrie via Android BiometricPrompt.
- OCR local via ML Kit Text Recognition ou moteur équivalent ; reconnaissance d'objets avec modèle embarqué.
- Intégration complète Home Assistant avec écran de configuration, liste des appareils et confirmations pour portes/serrures.
- Automatisations multi-étapes avec aperçu et confirmation avant action.
- Calendrier, alarmes et rappels système avec permissions dédiées.
- WhatsApp : préremplissage de texte et partage par l'interface Android.
- Traduction hors ligne avec modèles téléchargés.
- Synchronisation avec gestion des conflits, suppression synchronisée et comptes multi-utilisateurs.

## Niveau 3 — Intelligence avancée

- Conversation avec historique et mémoire contrôlée par l'utilisateur.
- Analyse de documents et d'images par IA, selon les choix de confidentialité.
- Assistant de programmation avec espaces de projet et éditeur.
- Résumés, planification et automatisations personnalisées.
- Mode urgence configuré par l'utilisateur (contacts, message, localisation si autorisée) sans appeler ni envoyer en secret.
- Extensions natives signées et modules distants contrôlés.

## Critères de validation

Chaque module doit avoir une description, un statut, une liste minimale d'autorisations, un test fonctionnel, un test de refus d'autorisation, une gestion d'erreur et une procédure de désactivation.


## Version 1.4.0 — Audio hybride et assistant connecté

- Ajout du détecteur local de mot-clé HELIOS avec Sherpa-ONNX KWS ; le modèle ONNX et le fichier de mot-clé sont préparés automatiquement par une tâche Gradle au premier build GitHub Actions.
- Ajout du service microphone Android au premier plan avec notification et arrêt de l'écoute après détection. L'utilisateur touche la notification avant de dicter sa commande.
- Extension du service d'accessibilité pour navigation, clic sur libellé visible et défilement, après activation manuelle par l'utilisateur.
- Ajout du proxy Gemini `generateContent` dans le serveur PHP ; la clé est stockée côté serveur seulement.
- Limites : mot-clé anglais/chinois avec phonétique HELIOS approximative à tester sur accent local ; la reconnaissance libre du français hors ligne dépend du pack Android ; Gemini reste en ligne ; l'accessibilité n'a pas un accès universel aux applications.
