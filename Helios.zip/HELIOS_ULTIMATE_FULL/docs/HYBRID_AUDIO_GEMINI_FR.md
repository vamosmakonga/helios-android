# HELIOS hybride : audio local, contrôle Android et Gemini

## Hors ligne

- Les notes, tâches et commandes prises en charge par `LocalCommandEngine` sont exécutées localement.
- Sherpa-ONNX exécute la détection du mot-clé `HELIOS` sur le téléphone. Aucun audio brut n'est envoyé au serveur par ce détecteur.
- Le modèle KWS est ajouté aux assets Android par GitHub Actions à partir de la publication officielle Sherpa-ONNX. Le premier build nécessite Internet ; l'écoute KWS de l'APK installé fonctionne ensuite localement.
- Après le mot de réveil, l'utilisateur touche la notification HELIOS. Le moteur SpeechRecognizer Android reconnaît la commande ; le hors-ligne français dépend du pack français installé par Google/Android.

## Contrôle Android façon Voice Access

Activez le service **HELIOS – contrôle vocal du téléphone** dans Paramètres Android > Accessibilité. HELIOS peut exécuter les actions globales autorisées, cliquer un libellé visible, et faire défiler une vue. Ce n'est pas un accès universel : les écrans protégés, boutons sans libellé, confirmations de paiement, envois, suppressions et appels restent à valider par l'utilisateur.

## Gemini connecté

1. Hébergez `server/` derrière HTTPS.
2. Créez `server/config.php` depuis l'exemple.
3. Configurez les variables d'environnement serveur `HELIOS_API_TOKEN`, `HELIOS_AI_PROVIDER=gemini`, `HELIOS_GEMINI_KEY` et `HELIOS_GEMINI_MODEL=gemini-3.5-flash-lite`.
4. Dans HELIOS, configurez l'URL `api/assistant.php` et le jeton `HELIOS_API_TOKEN`.

La clé Gemini est privée et reste sur le serveur. Ne l'ajoutez ni au dépôt GitHub, ni à l'APK, ni à un fichier livré au téléphone. La connexion Gemini utilise une clé API Google AI Studio, pas l'authentification Gmail personnelle. Gemini nécessite Internet et peut appliquer des quotas ou des frais.

## Restrictions Android et essais

- L'écoute du mot-clé se lance depuis l'application visible ; Android 14+ impose le service microphone au premier plan et sa notification.
- L'utilisateur doit accepter RECORD_AUDIO et les notifications.
- Les économies de batterie, le constructeur et l'arrêt forcé peuvent interrompre l'écoute en arrière-plan. Le redémarrage manuel depuis HELIOS peut être nécessaire.
- Le modèle de mot-clé pré-entraîné est anglais/chinois, avec lexique phonétique HELIOS ajouté au build. Il faut essayer « HELIOS » avec l'accent habituel ; la détection du français n'est pas garantie.
- Sur un téléphone à mémoire limitée, la configuration utilise un seul thread CPU et encodeur/joiner int8. Les performances réelles doivent être mesurées sur l'appareil.
