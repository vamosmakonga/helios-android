# Sécurité et limites Android

HELIOS doit être un assistant visible, contrôlable et révocable. Il ne doit pas fonctionner comme un outil de surveillance cachée.

## Principes

- Demander une permission uniquement au moment où une fonction l'exige.
- Expliquer ce qui sera lu, envoyé ou partagé avant l'activation.
- Ne pas capturer les notifications, SMS, appels, audio ou images sans autorisation explicite.
- Ne pas stocker le contenu des notifications dans cette version.
- Garder les notes et tâches en local tant que l'utilisateur ne choisit pas la synchronisation.
- Protéger les communications serveur par HTTPS.
- Garder les clés des fournisseurs IA côté serveur, jamais dans le code source de l'APK.
- Dans cette alpha, le jeton du serveur est enregistré dans les préférences Android et dans le `localStorage` du navigateur : ces stockages ne sont pas chiffrés par HELIOS. Ne réutilisez pas un jeton administrateur et évitez les appareils partagés. Une version de production doit utiliser Android Keystore et un stockage web adapté.
- Permettre la révocation des autorisations depuis les paramètres Android.

## Limites de l'application

- Les appels sont préparés dans le composeur Android ; HELIOS ne lance pas silencieusement un appel.
- Les SMS sont préparés dans l'application SMS ; l'utilisateur vérifie et envoie.
- WhatsApp est ouvert comme application externe. L'envoi automatique n'est pas implémenté.
- L'accès aux notifications nécessite l'activation manuelle du service dans les paramètres spécialisés Android. Le service fourni ne lit et ne stocke que le nom technique de l'application émettrice dans le journal de débogage.
- Le microphone est utilisé à la demande depuis l'écran visible. Le mot d'activation permanent n'est pas inclus.
- L'appareil photo est ouvert dans l'application caméra du téléphone. L'analyse d'images n'est pas encore incluse.
- Aucun accès aux mots de passe, aux données bancaires, au verrouillage de l'écran, ni aux réglages sécurisés du système n'est tenté.

## Avant une mise en production

Utiliser Android Keystore pour les jetons côté client, une authentification par utilisateur, des jetons révocables, une limitation de débit, des journaux minimisés, un audit de sécurité, des tests sur plusieurs versions Android et une politique de confidentialité claire.
