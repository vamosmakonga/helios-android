# Architecture d'extensions HELIOS

Chaque capacité est un module indépendant. L'application Android possède le contrat `HeliosModule` et un `ModuleRegistry` qui décrit les capacités, leur statut et leurs besoins.

## Ajouter une extension native

1. Créez un package dans `android/app/src/main/java/com/vamos/helios/modules/`.
2. Implémentez `HeliosModule` et, si nécessaire, un contrat spécialisé (`VisionProvider`, `WakeWordEngine` ou `AutomationAction`).
3. Déclarez le module dans `ModuleRegistry`.
4. Ajoutez ses autorisations Android uniquement si elles sont indispensables, expliquez-les à l'utilisateur et demandez-les au moment où la fonction est utilisée.
5. Ajoutez des tests et mettez à jour la documentation.
6. Recompilez et publiez une nouvelle version de l'application.

## Ajouter un module distant

Un module qui appelle une API peut être implémenté côté serveur PHP puis exposé à Android et au tableau web via un endpoint HTTPS. Ne placez pas de secret fournisseur dans le code client.

## Limite de sécurité importante

Cette version n'exécute pas du code arbitraire téléchargé depuis Internet. Installer du code natif à distance serait dangereux. Les extensions natives doivent être examinées, signées et distribuées dans une mise à jour contrôlée. Les manifests JSON décrivent les extensions mais ne suffisent pas à charger du code.
