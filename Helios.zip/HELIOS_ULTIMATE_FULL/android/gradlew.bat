@echo off
setlocal
set VERSION=9.6.0
if not defined GRADLE_USER_HOME set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set BASE=%GRADLE_USER_HOME%\wrapper\dists\gradle-%VERSION%-bin\helios
set GRADLE_HOME=%BASE%\gradle-%VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%BASE%" mkdir "%BASE%"
  echo Downloading Gradle %VERSION% from the official Gradle distribution server...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $z='%BASE%\gradle.zip'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile $z; $h=(Get-FileHash -Algorithm SHA256 $z).Hash.ToLower(); if ($h -ne 'bbaeb2fef8710818cf0e261201dab964c572f92b942812df0c3620d62a529a01') { throw 'Gradle checksum mismatch' }; Expand-Archive -Force $z '%BASE%'; Remove-Item $z"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
endlocal
