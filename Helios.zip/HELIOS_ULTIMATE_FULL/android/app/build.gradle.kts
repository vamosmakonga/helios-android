plugins {
    id("com.android.application")
}

android {
    namespace = "com.vamos.helios"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.vamos.helios"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "1.4.0-hybrid-sherpa-gemini"
        ndk {
            abiFilters += setOf("arm64-v8a", "armeabi-v7a")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}


dependencies {
    // Sherpa-ONNX Android runtime (JNI + Java API).
    implementation("com.github.k2-fsa:sherpa-onnx:v1.13.8")
}

// Prepare local wake-word model assets before Android resource processing.
// GitHub Actions has network access; the generated ONNX files are not stored in the source ZIP.
val prepareSherpaKwsAssets by tasks.registering(Exec::class) {
    val script = rootProject.file("scripts/prepare-sherpa-kws.sh")
    workingDir = rootProject.projectDir
    commandLine("bash", script.absolutePath)
    inputs.file(script)
    outputs.files(
        file("src/main/assets/kws/encoder.int8.onnx"),
        file("src/main/assets/kws/decoder.onnx"),
        file("src/main/assets/kws/joiner.int8.onnx"),
        file("src/main/assets/kws/tokens.txt"),
        file("src/main/assets/kws/keywords.txt")
    )
}

tasks.configureEach {
    if (name == "preBuild") dependsOn(prepareSherpaKwsAssets)
}
