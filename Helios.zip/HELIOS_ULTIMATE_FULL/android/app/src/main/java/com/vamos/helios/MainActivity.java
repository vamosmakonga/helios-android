package com.vamos.helios;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.vamos.helios.core.LocalCommandEngine;
import com.vamos.helios.data.LocalMemoryStore;
import com.vamos.helios.modules.HeliosModule;
import com.vamos.helios.modules.ModuleRegistry;
import com.vamos.helios.modules.ModuleStatus;
import com.vamos.helios.services.RemoteAssistantClient;
import com.vamos.helios.services.HeliosWakeWordService;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int REQUEST_AUDIO = 701;
    private static final int REQUEST_WAKE_AUDIO = 702;
    private static final int REQUEST_WAKE_NOTIFICATION = 703;
    private LinearLayout root;
    private EditText commandInput;
    private TextView responseView;
    private TextView statusView;
    private LocalMemoryStore memory;
    private LocalCommandEngine commandEngine;
    private ModuleRegistry moduleRegistry;
    private SpeechRecognizer speechRecognizer;
    private TextToSpeech textToSpeech;
    private boolean ttsReady = false;
    private boolean voiceFallbackAttempted = false;
    private boolean continuousListening = false;
    private Button voiceButton;
    private final Handler voiceHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        memory = new LocalMemoryStore(this);
        commandEngine = new LocalCommandEngine(this, memory);
        moduleRegistry = new ModuleRegistry();
        initializeSpeechOutput();
        buildInterface();
        if (getIntent() != null && getIntent().getBooleanExtra(HeliosWakeWordService.EXTRA_WAKE_TRIGGERED, false)) {
            voiceHandler.postDelayed(this::handleWakeNotification, 600);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra(HeliosWakeWordService.EXTRA_WAKE_TRIGGERED, false)) {
            voiceHandler.postDelayed(this::handleWakeNotification, 400);
        }
    }

    private void handleWakeNotification() {
        stopService(new Intent(this, HeliosWakeWordService.class));
        continuousListening = false;
        if (voiceButton != null) voiceButton.setText("🎙 Conversation continue : désactivée");
        showResponse("Mot d’activation HELIOS détecté hors ligne. Dites maintenant votre commande.", false);
        startVoiceInput();
    }

    private void startWakeWordListening() {
        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_WAKE_AUDIO);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_WAKE_NOTIFICATION);
            return;
        }
        launchWakeWordService();
    }

    private void launchWakeWordService() {
        try {
            Intent service = new Intent(this, HeliosWakeWordService.class).setAction(HeliosWakeWordService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
            statusView.setText("● SHERPA-ONNX : ÉCOUTE LOCALE ACTIVE");
            showResponse("Écoute locale activée. Le mot HELIOS est détecté sur l’appareil, sans envoyer le son sur Internet. Après détection, touchez la notification HELIOS pour donner votre commande.", false);
        } catch (Exception e) {
            showResponse("Impossible de démarrer l’écoute. Ouvrez HELIOS, autorisez le microphone et réessayez. Détail : " + e.getMessage(), false);
        }
    }

    private void stopWakeWordListening() {
        stopService(new Intent(this, HeliosWakeWordService.class));
        statusView.setText("● NOYAU LOCAL PRÊT");
        showResponse("Écoute du mot d’activation arrêtée.", false);
    }

    private void buildInterface() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(28));
        root.setBackgroundColor(Color.rgb(7, 16, 29));
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = new TextView(this);
        brand.setText("H E L I O S");
        brand.setTextColor(Color.rgb(64, 224, 208));
        brand.setTextSize(27);
        brand.setTypeface(Typeface.DEFAULT_BOLD);
        brand.setGravity(Gravity.CENTER);
        root.addView(brand, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("ULTIMATE FULL  •  ASSISTANT LOCAL ET VOCAL");
        subtitle.setTextColor(Color.rgb(165, 185, 205));
        subtitle.setTextSize(11);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(5), 0, dp(16));
        root.addView(subtitle, matchWrap());

        statusView = new TextView(this);
        statusView.setText("● NOYAU LOCAL PRÊT  |  INTERNET CONFIGURABLE");
        statusView.setTextColor(Color.rgb(116, 230, 180));
        statusView.setTextSize(12);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(dp(12), dp(12), dp(12), dp(12));
        statusView.setBackgroundColor(Color.rgb(15, 36, 49));
        root.addView(statusView, matchWrap());

        TextView welcome = new TextView(this);
        welcome.setText("SYSTÈME D’ASSISTANCE PERSONNELLE\nEN LIGNE • LOCAL • SÉCURISÉ");
        welcome.setTextColor(Color.rgb(173, 203, 222));
        welcome.setTextSize(11);
        welcome.setGravity(Gravity.CENTER);
        welcome.setPadding(dp(8), dp(18), dp(8), dp(2));
        root.addView(welcome, matchWrap());

        OrbView orb = new OrbView(this);
        LinearLayout.LayoutParams orbParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(210));
        orbParams.topMargin = dp(2);
        root.addView(orb, orbParams);
        TextView orbCaption = new TextView(this);
        orbCaption.setText("BONJOUR, JE SUIS HELIOS\nTouchez « Conversation continue » pour parler");
        orbCaption.setTextColor(Color.rgb(190, 213, 231));
        orbCaption.setTextSize(13);
        orbCaption.setGravity(Gravity.CENTER);
        orbCaption.setPadding(0, dp(2), 0, dp(16));
        root.addView(orbCaption, matchWrap());

        TextView commandLabel = sectionTitle("COMMANDES VOCALES ET TEXTUELLES");
        root.addView(commandLabel, matchWrap());
        commandInput = new EditText(this);
        commandInput.setSingleLine(false);
        commandInput.setMinLines(2);
        commandInput.setTextSize(16);
        commandInput.setTextColor(Color.WHITE);
        commandInput.setHintTextColor(Color.rgb(145, 159, 176));
        commandInput.setHint("Ex. : Bonjour HELIOS, note acheter du pain…");
        commandInput.setPadding(dp(14), dp(12), dp(14), dp(12));
        commandInput.setBackgroundColor(Color.rgb(21, 36, 53));
        commandInput.setImeOptions(EditorInfo.IME_ACTION_SEND);
        root.addView(commandInput, matchWrap());

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, dp(10), 0, dp(10));
        voiceButton = actionButton("🎙 Conversation continue : désactivée");
        Button sendButton = actionButton("Envoyer");
        actions.addView(voiceButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        LinearLayout.LayoutParams sendParams = new LinearLayout.LayoutParams(0, dp(48), 1);
        sendParams.setMargins(dp(8), 0, 0, 0);
        actions.addView(sendButton, sendParams);
        root.addView(actions, matchWrap());
        voiceButton.setOnClickListener(v -> {
            continuousListening = !continuousListening;
            voiceButton.setText(continuousListening
                    ? "⏹ Arrêter la conversation continue"
                    : "🎙 Conversation continue : désactivée");
            if (continuousListening) startVoiceInput();
            else {
                voiceHandler.removeCallbacksAndMessages(null);
                if (speechRecognizer != null) speechRecognizer.cancel();
                statusView.setText("● NOYAU LOCAL PRÊT");
                showResponse("Conversation continue arrêtée. Appuyez de nouveau pour reprendre.", false);
            }
        });
        sendButton.setOnClickListener(v -> submitTypedCommand());
        commandInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) { submitTypedCommand(); return true; }
            return false;
        });

        responseView = new TextView(this);
        responseView.setText("HELIOS fonctionne localement pour les commandes de base. Activez l’écoute Sherpa-ONNX depuis le Centre de commande pour détecter le mot HELIOS hors ligne.");
        responseView.setTextColor(Color.rgb(225, 236, 245));
        responseView.setTextSize(15);
        responseView.setPadding(dp(15), dp(16), dp(15), dp(16));
        responseView.setBackgroundColor(Color.rgb(14, 32, 52));
        root.addView(responseView, matchWrap());

        TextView memorySummary = new TextView(this);
        memorySummary.setText("MÉMOIRE LOCALE     NOTES : " + memory.getNotes().size()
                + "       TÂCHES : " + memory.getTasks().size());
        memorySummary.setTextColor(Color.rgb(64, 224, 208));
        memorySummary.setTextSize(12);
        memorySummary.setTypeface(Typeface.DEFAULT_BOLD);
        memorySummary.setGravity(Gravity.CENTER);
        memorySummary.setPadding(dp(8), dp(16), dp(8), dp(8));
        root.addView(memorySummary, matchWrap());

        Button commandCenterButton = actionButton("☷  CENTRE DE COMMANDE  •  OUVRIR");
        commandCenterButton.setTextSize(15);
        commandCenterButton.setPadding(dp(14), dp(8), dp(14), dp(8));
        LinearLayout.LayoutParams centerParams = matchWrap();
        centerParams.topMargin = dp(16);
        root.addView(commandCenterButton, centerParams);

        LinearLayout commandCenterPanel = new LinearLayout(this);
        commandCenterPanel.setOrientation(LinearLayout.VERTICAL);
        commandCenterPanel.setPadding(dp(12), dp(8), dp(12), dp(12));
        commandCenterPanel.setBackgroundColor(Color.rgb(12, 29, 47));
        commandCenterPanel.setVisibility(View.GONE);
        root.addView(commandCenterPanel, matchWrap());
        commandCenterButton.setOnClickListener(v -> {
            boolean opening = commandCenterPanel.getVisibility() != View.VISIBLE;
            commandCenterPanel.setVisibility(opening ? View.VISIBLE : View.GONE);
            commandCenterButton.setText(opening ? "☷  CENTRE DE COMMANDE  •  FERMER" : "☷  CENTRE DE COMMANDE  •  OUVRIR");
        });
        addPanelButton(commandCenterPanel, "📚 MES NOTES  •  " + memory.getNotes().size(), () -> showSavedItems("NOTES LOCALES", memory.getNotes()));
        addPanelButton(commandCenterPanel, "✓ MES TÂCHES  •  " + memory.getTasks().size(), () -> showSavedItems("TÂCHES LOCALES", memory.getTasks()));
        addPanelButton(commandCenterPanel, "＋ Ajouter une note", () -> promptMemoryEntry(false));
        addPanelButton(commandCenterPanel, "＋ Ajouter une tâche", () -> promptMemoryEntry(true));
        addPanelButton(commandCenterPanel, "🧩 Modules et capacités", this::showModules);
        addPanelButton(commandCenterPanel, "🎧 Activer le mot HELIOS (Sherpa-ONNX hors ligne)", this::startWakeWordListening);
        addPanelButton(commandCenterPanel, "⏹ Arrêter l’écoute du mot HELIOS", this::stopWakeWordListening);
        addPanelButton(commandCenterPanel, "♿ Activer le contrôle du téléphone", () -> {
            try {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                showResponse("Dans Accessibilité, sélectionnez HELIOS puis activez son service. Vous gardez le contrôle et pouvez le désactiver à tout moment.", false);
            } catch (Exception e) {
                showResponse("Impossible d’ouvrir les paramètres d’accessibilité sur cet appareil.", false);
            }
        });
        addPanelButton(commandCenterPanel, "🔔 Autoriser les notifications", () -> {
            try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); }
            catch (Exception e) { showResponse("Écran des autorisations de notifications indisponible sur cet appareil.", false); }
        });
        addPanelButton(commandCenterPanel, "⚙ Configurer le serveur IA / synchronisation", this::showServerSettings);
        addPanelButton(commandCenterPanel, "⇄ Synchroniser mes notes et tâches", this::syncLocalData);
        addPanelButton(commandCenterPanel, "Effacer la mémoire de conversation IA", this::confirmClearConversation);

        TextView footer = new TextView(this);
        footer.setText("HELIOS • Version hybride 1.4 • Vos notes restent sur cet appareil tant que vous ne configurez pas la synchronisation.");
        footer.setTextColor(Color.rgb(125, 145, 165));
        footer.setTextSize(11);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(22), 0, 0);
        root.addView(footer, matchWrap());
    }

    private void submitTypedCommand() {
        String command = commandInput.getText().toString().trim();
        if (command.isEmpty()) return;
        commandInput.setText("");
        hideKeyboard();
        runCommand(command);
    }

    private void runCommand(String command) {
        String normalized = command.trim().replaceFirst("(?i)^(bonjour|salut|ok|d’accord|d'accord)?\\s*helios[,:;.!?]?\\s*", "").trim();
        if (normalized.isEmpty()) normalized = command;
        String answer = commandEngine.execute(normalized);
        if (answer.startsWith("Je n'ai pas de réponse locale fiable")) {
            String endpoint = memory.getPreference("server_url", "").trim();
            String token = memory.getPreference("server_token", "").trim();
            if (!endpoint.isEmpty()) {
                showResponse("Je consulte le moteur intelligent…", false);
                org.json.JSONArray history = memory.getConversationHistory();
                memory.addConversationTurn("user", command);
                RemoteAssistantClient.ask(endpoint, token, command, history, new RemoteAssistantClient.Callback() {
                    @Override public void onSuccess(String reply) {
                        memory.addConversationTurn("assistant", reply);
                        runOnUiThread(() -> showResponse(reply, true));
                    }
                    @Override public void onError(String message) {
                        runOnUiThread(() -> showResponse(message + "\nJe reste disponible en mode local.", true));
                    }
                });
                return;
            }
        }
        showResponse(answer, true);
    }

    private void showResponse(String text, boolean speak) {
        responseView.setText(text);
        if (speak && ttsReady && textToSpeech != null) {
            textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "helios-reply");
        } else if (continuousListening) {
            scheduleNextListening();
        }
    }

    private void initializeSpeechOutput() {
        textToSpeech = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int languageStatus = textToSpeech.setLanguage(Locale.FRANCE);
                ttsReady = languageStatus != TextToSpeech.LANG_MISSING_DATA
                        && languageStatus != TextToSpeech.LANG_NOT_SUPPORTED;
                textToSpeech.setSpeechRate(0.94f);
                textToSpeech.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) { }
                    @Override public void onDone(String utteranceId) {
                        if (continuousListening) runOnUiThread(() -> scheduleNextListening());
                    }
                    @Override public void onError(String utteranceId) {
                        if (continuousListening) runOnUiThread(() -> scheduleNextListening());
                    }
                });
                // Select a voice explicitly marked as male when the installed engine exposes that metadata.
                if (Build.VERSION.SDK_INT >= 21 && textToSpeech.getVoices() != null) {
                    Set<Voice> voices = textToSpeech.getVoices();
                    for (Voice voice : voices) {
                        String name = voice.getName().toLowerCase(Locale.ROOT);
                        boolean french = voice.getLocale() != null && "fr".equals(voice.getLocale().getLanguage());
                        boolean markedMale = name.contains("male") || name.contains("masculin") || name.contains("homme");
                        if (french && markedMale) { textToSpeech.setVoice(voice); break; }
                    }
                }
            }
        });
    }

    private void startVoiceInput() {
        voiceFallbackAttempted = false;
        startVoiceInput(true);
    }

    private void startVoiceInput(boolean preferOffline) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_AUDIO);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            showResponse("Aucun service de reconnaissance vocale n'est disponible. Utilisez le champ texte ou installez une reconnaissance vocale compatible.", false);
            return;
        }
        try {
            if (speechRecognizer != null) speechRecognizer.destroy();
            if (preferOffline && Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                speechRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            } else {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            }
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { statusView.setText("● HELIOS ÉCOUTE…"); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { statusView.setText("● ANALYSE DE LA COMMANDE…"); }
                @Override public void onError(int error) {
                    if (preferOffline && !voiceFallbackAttempted
                            && (error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED
                            || error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE)) {
                        voiceFallbackAttempted = true;
                        statusView.setText("● ESSAI DE RECONNAISSANCE EN LIGNE…");
                        startVoiceInput(false);
                        return;
                    }
                    statusView.setText("● NOYAU LOCAL PRÊT");
                    if (continuousListening) {
                        scheduleNextListening();
                        return;
                    }
                    String detail = error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED
                            || error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE
                            ? "Le français hors ligne n'est pas disponible. Vérifiez votre connexion et le service vocal Google."
                            : "Vérifiez le microphone et le service de reconnaissance vocale.";
                    showResponse("Reconnaissance vocale impossible (code " + error + "). " + detail, false);
                }
                @Override public void onResults(Bundle results) {
                    statusView.setText("● NOYAU LOCAL PRÊT");
                    ArrayList<String> matches = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) {
                        runCommand(matches.get(0));
                    } else if (continuousListening) {
                        scheduleNextListening();
                    }
                }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR");
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fr-FR");
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, preferOffline
                    ? "Parlez à HELIOS (mode hors ligne)" : "Parlez à HELIOS (mode connecté)");
            speechRecognizer.startListening(intent);
        } catch (Exception exception) {
            showResponse("Démarrage de la reconnaissance vocale impossible : " + exception.getMessage(), false);
        }
    }

    private void scheduleNextListening() {
        if (!continuousListening || isFinishing()) return;
        voiceHandler.removeCallbacksAndMessages(null);
        voiceHandler.postDelayed(() -> {
            if (continuousListening && !isFinishing()) startVoiceInput();
        }, 900);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_AUDIO && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startVoiceInput();
        } else if (requestCode == REQUEST_AUDIO) {
            showResponse("L'accès au microphone a été refusé. Vous pouvez continuer avec le clavier.", false);
        } else if (requestCode == REQUEST_WAKE_AUDIO && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startWakeWordListening();
        } else if (requestCode == REQUEST_WAKE_AUDIO) {
            showResponse("L’écoute hors ligne nécessite l’autorisation du microphone.", false);
        } else if (requestCode == REQUEST_WAKE_NOTIFICATION && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            launchWakeWordService();
        } else if (requestCode == REQUEST_WAKE_NOTIFICATION) {
            showResponse("Autorisez les notifications pour pouvoir toucher l’alerte lorsque le mot HELIOS est détecté.", false);
        }
    }

    private void syncLocalData() {
        String endpoint = memory.getPreference("server_url", "").trim();
        String token = memory.getPreference("server_token", "").trim();
        if (endpoint.isEmpty()) {
            showResponse("Configurez d'abord l'URL du serveur HELIOS.", false);
            return;
        }
        org.json.JSONObject data = new org.json.JSONObject();
        try {
            data.put("notes", new org.json.JSONArray(memory.getNotes()));
            data.put("tasks", new org.json.JSONArray(memory.getTasks()));
        } catch (org.json.JSONException exception) {
            showResponse("Préparation de la synchronisation impossible.", false);
            return;
        }
        showResponse("Synchronisation en cours…", false);
        RemoteAssistantClient.sync(endpoint, token, data, new RemoteAssistantClient.Callback() {
            @Override public void onSuccess(String reply) {
                runOnUiThread(() -> {
                    try {
                        org.json.JSONObject merged = new org.json.JSONObject(reply);
                        memory.replaceSyncedItems(jsonArrayToStrings(merged.optJSONArray("notes")), jsonArrayToStrings(merged.optJSONArray("tasks")));
                        showResponse("Synchronisation terminée. Notes et tâches locales mises à jour.", false);
                    } catch (org.json.JSONException exception) {
                        showResponse("Le serveur a répondu, mais les données reçues sont illisibles.", false);
                    }
                });
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> showResponse(message, false));
            }
        });
    }

    private List<String> jsonArrayToStrings(org.json.JSONArray array) {
        ArrayList<String> values = new ArrayList<>();
        if (array == null) return values;
        for (int i = 0; i < array.length(); i++) values.add(array.optString(i, ""));
        return values;
    }

    private void showServerSettings() {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(8), dp(6), dp(8), dp(6));
        EditText endpoint = new EditText(this);
        endpoint.setSingleLine(true);
        endpoint.setHint("https://votre-domaine.tld/api/assistant.php");
        endpoint.setText(memory.getPreference("server_url", ""));
        EditText token = new EditText(this);
        token.setSingleLine(true);
        token.setHint("Jeton d'accès HELIOS (facultatif si serveur local)");
        token.setText(memory.getPreference("server_token", ""));
        form.addView(endpoint, matchWrap());
        form.addView(token, matchWrap());
        new AlertDialog.Builder(this)
                .setTitle("Connexion au serveur HELIOS")
                .setMessage("Le serveur permet la conversation IA et la synchronisation. Utilisez une adresse HTTPS publique. Ne partagez jamais votre jeton.")
                .setView(form)
                .setNegativeButton("Annuler", null)
                .setNeutralButton("Effacer", (dialog, which) -> {
                    memory.savePreference("server_url", "");
                    memory.savePreference("server_token", "");
                    showResponse("Configuration du serveur effacée.", false);
                })
                .setPositiveButton("Enregistrer", (dialog, which) -> {
                    String url = endpoint.getText().toString().trim();
                    if (!url.isEmpty() && !url.startsWith("https://")) {
                        Toast.makeText(this, "Utilisez HTTPS pour protéger les échanges.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    memory.savePreference("server_url", url);
                    memory.savePreference("server_token", token.getText().toString().trim());
                    showResponse(url.isEmpty() ? "Mode local uniquement." : "Serveur enregistré. Envoyez une question pour tester la connexion.", false);
                }).show();
    }

    private void confirmClearConversation() {
        new AlertDialog.Builder(this)
                .setTitle("Effacer la mémoire IA ?")
                .setMessage("Cette action supprime l'historique de conversation enregistré localement sur cet appareil. Les notes et les tâches ne seront pas touchées.")
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Effacer", (dialog, which) -> {
                    memory.clearConversationHistory();
                    showResponse("Mémoire de conversation effacée sur cet appareil.", false);
                }).show();
    }

    private void showModules() {
        List<HeliosModule> modules = moduleRegistry.all();
        String[] labels = new String[modules.size()];
        for (int i = 0; i < modules.size(); i++) {
            HeliosModule module = modules.get(i);
            labels[i] = module.displayName() + " — " + statusLabel(module.status()) + "\n" + module.description();
        }
        new AlertDialog.Builder(this)
                .setTitle("Modules HELIOS")
                .setItems(labels, (dialog, which) -> {
                    HeliosModule selected = modules.get(which);
                    showResponse(selected.displayName() + "\nÉtat : " + statusLabel(selected.status()) + "\n" + selected.description(), false);
                })
                .setPositiveButton("Fermer", null)
                .show();
    }

    private String statusLabel(ModuleStatus status) {
        switch (status) {
            case READY: return "disponible";
            case NEEDS_PERMISSION: return "autorisation à accorder";
            case NEEDS_CONFIGURATION: return "configuration requise";
            default: return "à développer";
        }
    }

    private void showSavedItems(String title, List<String> values) {
        if (values.isEmpty()) {
            new AlertDialog.Builder(this).setTitle(title).setMessage("Aucun élément enregistré.").setPositiveButton("OK", null).show();
            return;
        }
        StringBuilder content = new StringBuilder();
        int start = Math.max(0, values.size() - 30);
        for (int i = start; i < values.size(); i++) content.append("• ").append(values.get(i)).append("\n\n");
        new AlertDialog.Builder(this).setTitle(title).setMessage(content.toString()).setPositiveButton("Fermer", null).show();
    }

    private void promptMemoryEntry(boolean task) {
        EditText field = new EditText(this);
        field.setHint(task ? "Ex. : Étudier JavaScript" : "Ex. : Appeler mon client demain");
        new AlertDialog.Builder(this)
                .setTitle(task ? "Nouvelle tâche" : "Nouvelle note")
                .setView(field)
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Enregistrer", (dialog, which) -> {
                    String value = field.getText().toString().trim();
                    if (value.isEmpty()) {
                        Toast.makeText(this, "Écrivez d’abord un texte.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (task) memory.addTask(value); else memory.addNote(value);
                    showResponse(task ? "Tâche enregistrée sur ce téléphone." : "Note enregistrée sur ce téléphone.", true);
                    buildInterface();
                }).show();
    }

    private void addPanelButton(LinearLayout panel, String label, Runnable action) {
        Button button = actionButton(label);
        button.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        button.setPadding(dp(14), 0, dp(10), 0);
        LinearLayout.LayoutParams params = matchWrap();
        params.topMargin = dp(6);
        panel.addView(button, params);
        button.setOnClickListener(v -> action.run());
    }

    private void addQuickButton(String label, Runnable action) {
        Button button = actionButton(label);
        button.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        button.setPadding(dp(15), 0, dp(12), 0);
        LinearLayout.LayoutParams params = matchWrap();
        params.topMargin = dp(8);
        root.addView(button, params);
        button.setOnClickListener(v -> action.run());
    }

    private TextView sectionTitle(String title) {
        TextView label = new TextView(this);
        label.setText(title);
        label.setTextColor(Color.rgb(64, 224, 208));
        label.setTextSize(11);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        label.setPadding(0, dp(10), 0, dp(8));
        return label;
    }

    private Button actionButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextAllCaps(false);
        button.setTextColor(Color.rgb(7, 16, 29));
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(64, 224, 208)));
        return button;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams withTopMargin(LinearLayout.LayoutParams params, int margin) {
        params.topMargin = margin;
        return params;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void hideKeyboard() {
        try {
            android.view.inputmethod.InputMethodManager manager = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            manager.hideSoftInputFromWindow(commandInput.getWindowToken(), 0);
        } catch (Exception ignored) { }
    }

    @Override
    protected void onDestroy() {
        continuousListening = false;
        voiceHandler.removeCallbacksAndMessages(null);
        if (speechRecognizer != null) { speechRecognizer.cancel(); speechRecognizer.destroy(); speechRecognizer = null; }
        if (textToSpeech != null) { textToSpeech.stop(); textToSpeech.shutdown(); textToSpeech = null; }
        super.onDestroy();
    }
    /** Lightweight animated HUD orb; no image downloads, data use or third-party library. */
    private final class OrbView extends View {
        private final android.graphics.Paint paint = new android.graphics.Paint(3);
        private final Handler animator = new Handler(Looper.getMainLooper());
        private float phase = 0f;
        private final Runnable frame = new Runnable() {
            @Override public void run() {
                phase += 0.045f;
                if (phase > 6.283f) phase = 0f;
                invalidate();
                if (!isFinishing()) animator.postDelayed(this, 45);
            }
        };
        OrbView(Activity context) { super(context); setLayerType(View.LAYER_TYPE_SOFTWARE, null); animator.post(frame); }
        @Override protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth()/2f, cy = getHeight()/2f;
            float pulse = 1f + 0.035f * (float)Math.sin(phase);
            paint.setStyle(android.graphics.Paint.Style.STROKE);
            paint.setStrokeWidth(dp(1));
            paint.setColor(Color.argb(90, 64, 224, 208));
            canvas.drawCircle(cx, cy, dp(83)*pulse, paint);
            paint.setStrokeWidth(dp(2));
            paint.setColor(Color.argb(150, 49, 180, 220));
            canvas.drawCircle(cx, cy, dp(70), paint);
            paint.setStyle(android.graphics.Paint.Style.FILL);
            paint.setShader(new android.graphics.RadialGradient(cx, cy, dp(64),
                    new int[]{Color.rgb(66, 218, 226), Color.rgb(19, 87, 130), Color.rgb(8, 22, 43)},
                    null, android.graphics.Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, cy, dp(57)*pulse, paint);
            paint.setShader(null);
            paint.setStyle(android.graphics.Paint.Style.STROKE);
            paint.setStrokeWidth(dp(2));
            paint.setColor(Color.argb(190, 128, 246, 255));
            canvas.drawArc(cx-dp(76), cy-dp(76), cx+dp(76), cy+dp(76),
                    (float)Math.toDegrees(phase), 105, false, paint);
            paint.setStyle(android.graphics.Paint.Style.FILL);
            paint.setColor(Color.WHITE);
            paint.setTextAlign(android.graphics.Paint.Align.CENTER);
            paint.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
            paint.setTextSize(dp(25));
            canvas.drawText("J", cx, cy+dp(9), paint);
            paint.setTextSize(dp(9));
            paint.setColor(Color.rgb(145, 235, 244));
            canvas.drawText("HELIOS CORE", cx, cy+dp(30), paint);
        }
        @Override protected void onDetachedFromWindow() { animator.removeCallbacks(frame); super.onDetachedFromWindow(); }
    }

}
