package com.vamos.helios.data;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/** Local-first storage. Notes and tasks stay on this device until the user exports/synchronizes them. */
public final class LocalMemoryStore {
    private static final String PREFS = "helios_local_memory_v1";
    private final SharedPreferences preferences;

    public LocalMemoryStore(Context context) {
        preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public synchronized void addNote(String text) {
        append("notes", text);
    }

    public synchronized void addTask(String text) {
        append("tasks", text);
    }

    public synchronized List<String> getNotes() {
        return read("notes");
    }

    public synchronized List<String> getTasks() {
        return read("tasks");
    }

    public synchronized void replaceSyncedItems(List<String> notes, List<String> tasks) {
        preferences.edit()
                .putString("notes", new JSONArray(notes).toString())
                .putString("tasks", new JSONArray(tasks).toString())
                .apply();
    }

    public synchronized void savePreference(String key, String value) {
        preferences.edit().putString("pref_" + key, value).apply();
    }

    public synchronized String getPreference(String key, String fallback) {
        return preferences.getString("pref_" + key, fallback);
    }

    public synchronized void rememberLastCommand(String command) {
        preferences.edit().putString("last_command", command).apply();
    }

    public synchronized JSONArray getConversationHistory() {
        try {
            return new JSONArray(preferences.getString("conversation", "[]"));
        } catch (JSONException exception) {
            return new JSONArray();
        }
    }

    public synchronized void addConversationTurn(String role, String content) {
        JSONArray history = getConversationHistory();
        JSONObject turn = new JSONObject();
        try {
            turn.put("role", role);
            turn.put("content", content);
            history.put(turn);
        } catch (JSONException ignored) { return; }
        JSONArray recent = new JSONArray();
        int start = Math.max(0, history.length() - 20);
        for (int i = start; i < history.length(); i++) recent.put(history.opt(i));
        preferences.edit().putString("conversation", recent.toString()).apply();
    }

    public synchronized void clearConversationHistory() {
        preferences.edit().remove("conversation").apply();
    }

    private void append(String key, String text) {
        JSONArray array;
        try {
            array = new JSONArray(preferences.getString(key, "[]"));
        } catch (JSONException exception) {
            array = new JSONArray();
        }
        String timestamp = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                .format(new Date());
        array.put(timestamp + " — " + text.trim());
        preferences.edit().putString(key, array.toString()).apply();
    }

    private List<String> read(String key) {
        ArrayList<String> values = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(preferences.getString(key, "[]"));
            for (int i = 0; i < array.length(); i++) {
                values.add(array.optString(i, ""));
            }
        } catch (JSONException ignored) {
            // A damaged local list is treated as empty rather than crashing the assistant.
        }
        return values;
    }
}
