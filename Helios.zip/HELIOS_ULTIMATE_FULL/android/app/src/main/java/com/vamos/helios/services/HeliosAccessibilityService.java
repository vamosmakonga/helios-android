package com.vamos.helios.services;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.text.Normalizer;
import java.util.Locale;

/**
 * Optional user-enabled accessibility bridge for basic Android navigation.
 * It performs only explicit commands initiated by HELIOS; it does not monitor
 * or read screen contents for remote transmission.
 */
public class HeliosAccessibilityService extends AccessibilityService {
    private static HeliosAccessibilityService instance;

    @Override public void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* No passive collection. */ }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }

    public static boolean isEnabled() { return instance != null; }

    public static boolean perform(String action) {
        if (instance == null || action == null) return false;
        switch (action) {
            case "back": return instance.performGlobalAction(GLOBAL_ACTION_BACK);
            case "home": return instance.performGlobalAction(GLOBAL_ACTION_HOME);
            case "notifications": return instance.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
            case "quick_settings": return instance.performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS);
            case "recent": return instance.performGlobalAction(GLOBAL_ACTION_RECENTS);
            case "scroll_down": return instance.scrollActiveWindow(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
            case "scroll_up": return instance.scrollActiveWindow(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
            default: return false;
        }
    }

    /** Clicks a visible UI control matching the spoken label; traversal stays on-device. */
    public static boolean clickVisibleControl(String spokenLabel) {
        if (instance == null || spokenLabel == null || spokenLabel.trim().isEmpty()) return false;
        AccessibilityNodeInfo root = instance.getRootInActiveWindow();
        if (root == null) return false;
        try { return instance.findAndClick(root, normalize(spokenLabel)); }
        finally { root.recycle(); }
    }

    private boolean findAndClick(AccessibilityNodeInfo node, String target) {
        if (node == null) return false;
        CharSequence text = node.getText();
        CharSequence description = node.getContentDescription();
        boolean matches = matchesLabel(text, target) || matchesLabel(description, target);
        if (matches && node.isEnabled() && node.isVisibleToUser()) {
            if (node.isClickable() && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            AccessibilityNodeInfo parent = node.getParent();
            if (parent != null) {
                try { if (parent.isClickable() && parent.isEnabled()) return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK); }
                finally { parent.recycle(); }
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { if (findAndClick(child, target)) return true; }
                finally { child.recycle(); }
            }
        }
        return false;
    }

    private boolean scrollActiveWindow(int action) {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return false;
        try { return findScrollable(root, action); }
        finally { root.recycle(); }
    }

    private boolean findScrollable(AccessibilityNodeInfo node, int action) {
        if (node == null) return false;
        if (node.isScrollable() && node.isEnabled() && node.performAction(action)) return true;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                try { if (findScrollable(child, action)) return true; }
                finally { child.recycle(); }
            }
        }
        return false;
    }

    private boolean matchesLabel(CharSequence label, String target) {
        if (label == null) return false;
        String value = normalize(label.toString());
        return value.equals(target) || value.contains(target);
    }

    private static String normalize(String value) {
        return Normalizer.normalize(value == null ? "" : value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "").toLowerCase(Locale.ROOT).trim();
    }
}
