package com.vamos.helios.modules;

public enum ModuleStatus {
    READY,
    NEEDS_PERMISSION,
    NEEDS_CONFIGURATION,
    PLANNED
}
