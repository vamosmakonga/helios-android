package com.vamos.helios.modules;

import android.net.Uri;
import android.content.Context;

/** Extension point for on-device OCR, object recognition and image understanding. */
public interface VisionProvider {
    interface Callback { void onResult(String description); void onError(String message); }
    void readDocument(Context context, Uri imageUri, Callback callback);
    void recognizeObjects(Context context, Uri imageUri, Callback callback);
}
