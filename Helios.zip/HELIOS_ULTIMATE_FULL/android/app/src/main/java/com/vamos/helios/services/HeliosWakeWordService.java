package com.vamos.helios.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import com.k2fsa.sherpa.onnx.KeywordSpotter;
import com.k2fsa.sherpa.onnx.KeywordSpotterConfig;
import com.k2fsa.sherpa.onnx.OnlineModelConfig;
import com.k2fsa.sherpa.onnx.OnlineStream;
import com.k2fsa.sherpa.onnx.OnlineTransducerModelConfig;
import com.vamos.helios.MainActivity;
import com.vamos.helios.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * User-started foreground microphone service. Keyword detection is local with sherpa-onnx.
 * It does not upload or save microphone audio. After detection it stops recording and
 * shows a notification; the user taps it to start the normal HELIOS command recognizer.
 */
public final class HeliosWakeWordService extends Service {
    public static final String ACTION_START = "com.vamos.helios.action.START_WAKE_WORD";
    public static final String ACTION_STOP = "com.vamos.helios.action.STOP_WAKE_WORD";
    public static final String EXTRA_WAKE_TRIGGERED = "helios_wake_triggered";
    private static final String TAG = "HeliosWakeWord";
    private static final String CHANNEL_ID = "helios_wake_word";
    private static final int NOTIFICATION_ID = 4812;
    private static final int SAMPLE_RATE = 16000;

    private final AtomicBoolean listening = new AtomicBoolean(false);
    private volatile AudioRecord audioRecord;
    private Thread worker;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopListening();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startForegroundCompat(buildNotification("Préparation du moteur hors ligne…", false));
        if (listening.compareAndSet(false, true)) {
            worker = new Thread(this::runKeywordSpotter, "helios-sherpa-kws");
            worker.start();
        }
        return START_NOT_STICKY;
    }

    private void runKeywordSpotter() {
        KeywordSpotter spotter = null;
        OnlineStream stream = null;
        AudioRecord recorder = null;
        boolean keywordDetected = false;
        try {
            File modelDir = prepareModelFiles();
            String encoder = new File(modelDir, "encoder.int8.onnx").getAbsolutePath();
            String decoder = new File(modelDir, "decoder.onnx").getAbsolutePath();
            String joiner = new File(modelDir, "joiner.int8.onnx").getAbsolutePath();
            String tokens = new File(modelDir, "tokens.txt").getAbsolutePath();
            String keywords = new File(modelDir, "keywords.txt").getAbsolutePath();

            OnlineTransducerModelConfig transducer = OnlineTransducerModelConfig.builder()
                    .setEncoder(encoder).setDecoder(decoder).setJoiner(joiner).build();
            OnlineModelConfig model = OnlineModelConfig.builder()
                    .setTransducer(transducer).setTokens(tokens).setNumThreads(1).setDebug(false)
                    .setModelingUnit("phone+ppinyin").build();
            KeywordSpotterConfig config = KeywordSpotterConfig.builder()
                    .setOnlineModelConfig(model).setKeywordsFile(keywords)
                    .setKeywordsScore(1.0f).setKeywordsThreshold(0.30f).build();
            spotter = new KeywordSpotter(config);
            stream = spotter.createStream();

            int minBuffer = AudioRecord.getMinBufferSize(SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (minBuffer <= 0) throw new IllegalStateException("Taille du tampon audio non prise en charge.");
            int bufferBytes = Math.max(minBuffer * 2, SAMPLE_RATE / 2);
            recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferBytes);
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED) {
                throw new IllegalStateException("Le microphone ne peut pas être initialisé.");
            }
            audioRecord = recorder;
            recorder.startRecording();
            updateNotification("Écoute locale active — dites « HELIOS »", false);

            short[] pcm = new short[2048];
            while (listening.get() && !Thread.currentThread().isInterrupted()) {
                int count = recorder.read(pcm, 0, pcm.length);
                if (count == AudioRecord.ERROR_DEAD_OBJECT || count == AudioRecord.ERROR_INVALID_OPERATION
                        || count == AudioRecord.ERROR_BAD_VALUE) {
                    throw new IOException("Lecture du microphone interrompue (" + count + ").");
                }
                if (count == 0) continue;
                float[] samples = new float[count];
                for (int i = 0; i < count; i++) samples[i] = pcm[i] / 32768.0f;
                stream.acceptWaveform(samples, SAMPLE_RATE);
                while (spotter.isReady(stream)) {
                    spotter.decode(stream);
                    String keyword = spotter.getResult(stream).getKeyword();
                    if (keyword != null && !keyword.trim().isEmpty()) {
                        listening.set(false);
                        keywordDetected = true;
                        updateNotification("Mot HELIOS détecté — appuyez pour parler", true);
                        Log.i(TAG, "Wake word detected locally: " + keyword);
                        break;
                    }
                }
            }
        } catch (Exception | LinkageError e) {
            Log.e(TAG, "Wake-word engine stopped", e);
            listening.set(false);
            updateErrorNotification("Écoute arrêtée : " + safeMessage(e));
            new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_DETACH);
                else stopForeground(false);
                stopSelf();
            });
        } finally {
            audioRecord = null;
            if (recorder != null) {
                try { if (recorder.getRecordingState() == AudioRecord.RECORDSTATE_RECORDING) recorder.stop(); }
                catch (Exception ignored) { }
                recorder.release();
            }
            if (stream != null) {
                try { stream.release(); } catch (Exception ignored) { }
            }
            if (spotter != null) {
                try { spotter.release(); } catch (Exception ignored) { }
            }
            if (keywordDetected) {
                new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                    if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_DETACH);
                    else stopForeground(false);
                    stopSelf();
                });
            }
        }
    }

    private File prepareModelFiles() throws IOException {
        String[] names = {"encoder.int8.onnx", "decoder.onnx", "joiner.int8.onnx", "tokens.txt", "keywords.txt"};
        File directory = new File(getFilesDir(), "helios-kws");
        if (!directory.exists() && !directory.mkdirs()) throw new IOException("Impossible de créer le dossier du modèle.");
        for (String name : names) {
            File target = new File(directory, name);
            if (target.isFile() && target.length() > 0) continue;
            try (InputStream input = getAssets().open("kws/" + name);
                 FileOutputStream output = new FileOutputStream(target)) {
                byte[] buffer = new byte[8192];
                int read;
                while ((read = input.read(buffer)) != -1) output.write(buffer, 0, read);
            }
        }
        return directory;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Écoute vocale HELIOS", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Service d'écoute locale du mot d'activation HELIOS");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String message, boolean wakeDetected) {
        return buildNotification(message, wakeDetected, !wakeDetected);
    }

    private Notification buildNotification(String message, boolean wakeDetected, boolean ongoing) {
        Intent open = new Intent(this, MainActivity.class)
                .putExtra(EXTRA_WAKE_TRIGGERED, wakeDetected)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pending = PendingIntent.getActivity(this, 4813, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        String title = wakeDetected ? "HELIOS est prêt" : (ongoing ? "HELIOS — écoute hors ligne" : "HELIOS — écoute arrêtée");
        return builder.setSmallIcon(R.drawable.ic_helios_foreground)
                .setContentTitle(title)
                .setContentText(message)
                .setContentIntent(pending)
                .setOngoing(ongoing)
                .setAutoCancel(!ongoing)
                .build();
    }

    private void startForegroundCompat(Notification notification) {
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void updateNotification(String text, boolean wakeDetected) {
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(text, wakeDetected));
    }

    private void updateErrorNotification(String text) {
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.notify(NOTIFICATION_ID, buildNotification(text, false, false));
    }

    private String safeMessage(Throwable e) {
        String message = e.getMessage();
        return message == null || message.trim().isEmpty() ? "vérifiez le modèle et les autorisations" : message;
    }

    private void stopListening() {
        listening.set(false);
        AudioRecord current = audioRecord;
        if (current != null) {
            try { current.stop(); } catch (Exception ignored) { }
        }
        if (worker != null) worker.interrupt();
    }

    @Override public void onDestroy() {
        stopListening();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
