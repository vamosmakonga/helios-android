package com.vamos.helios.modules;

/** Adapter contract for a future on-device hotword engine such as a licensed/local keyword spotter. */
public interface WakeWordEngine {
    interface Listener { void onWakeWordDetected(); void onEngineError(String message); }
    boolean isAvailable();
    void start(Listener listener);
    void stop();
}
