#!/usr/bin/env bash
set -euo pipefail

ANDROID_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEST="$ANDROID_ROOT/app/src/main/assets/kws"
REQUIRED=(encoder.int8.onnx decoder.onnx joiner.int8.onnx tokens.txt keywords.txt)

all_ready=true
for file in "${REQUIRED[@]}"; do
  [[ -s "$DEST/$file" ]] || all_ready=false
done
if [[ "$all_ready" == true ]]; then
  echo "Sherpa-ONNX KWS assets already prepared."
  exit 0
fi

command -v curl >/dev/null || { echo "curl est requis pour télécharger le modèle Sherpa-ONNX." >&2; exit 1; }
command -v tar >/dev/null || { echo "tar est requis pour extraire le modèle Sherpa-ONNX." >&2; exit 1; }

WORK="${TMPDIR:-/tmp}/helios-sherpa-kws"
ARCHIVE="$WORK/model.tar.bz2"
MODEL_ROOT="$WORK/model"
MODEL_DIR="$MODEL_ROOT/sherpa-onnx-kws-zipformer-zh-en-3M-2025-12-20"
mkdir -p "$WORK" "$MODEL_ROOT" "$DEST"

if [[ ! -s "$MODEL_DIR/tokens.txt" ]]; then
  curl -fsSL --retry 3 \
    "https://github.com/k2-fsa/sherpa-onnx/releases/download/kws-models/sherpa-onnx-kws-zipformer-zh-en-3M-2025-12-20.tar.bz2" \
    -o "$ARCHIVE"
  tar -xjf "$ARCHIVE" -C "$MODEL_ROOT"
fi

cp "$MODEL_DIR/encoder-epoch-13-avg-2-chunk-16-left-64.int8.onnx" "$DEST/encoder.int8.onnx"
cp "$MODEL_DIR/decoder-epoch-13-avg-2-chunk-16-left-64.onnx" "$DEST/decoder.onnx"
cp "$MODEL_DIR/joiner-epoch-13-avg-2-chunk-16-left-64.int8.onnx" "$DEST/joiner.int8.onnx"
cp "$MODEL_DIR/tokens.txt" "$DEST/tokens.txt"

# KWS token line: English phonemes followed by the threshold and original keyword label.
# This approximates the English pronunciation of HELIOS; test it with the user's accent.
printf 'HH IY1 L IY0 OW0 S #0.30 @HELIOS\n' > "$DEST/keywords.txt"

for file in "${REQUIRED[@]}"; do
  [[ -s "$DEST/$file" ]] || { echo "Asset Sherpa-ONNX manquant : $file" >&2; exit 1; }
done

echo "Sherpa-ONNX KWS assets prepared: $(du -sh "$DEST" | cut -f1)"
