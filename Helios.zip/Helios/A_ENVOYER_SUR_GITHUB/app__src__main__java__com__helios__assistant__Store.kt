package com.helios.assistant

import android.content.Context
import org.json.JSONArray

object Store {
    // Indicatif pays ajouté aux numéros qui commencent par 0 (243 = RD Congo). Modifiable.
    const val COUNTRY_CODE = "243"

    private fun sp(c: Context) = c.getSharedPreferences("helios", Context.MODE_PRIVATE)

    fun get(c: Context, k: String, d: String = ""): String = sp(c).getString(k, d) ?: d

    fun put(c: Context, k: String, v: String) {
        sp(c).edit().putString(k, v).apply()
    }

    fun flag(c: Context, k: String): Boolean = sp(c).getBoolean(k, false)

    fun setFlag(c: Context, k: String, v: Boolean) {
        sp(c).edit().putBoolean(k, v).apply()
    }

    fun lang(c: Context): String = get(c, "lang", "fr")

    fun list(c: Context, k: String): MutableList<String> {
        val out = mutableListOf<String>()
        try {
            val a = JSONArray(get(c, k, "[]"))
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (e: Exception) {
        }
        return out
    }

    fun saveList(c: Context, k: String, l: List<String>) {
        put(c, k, JSONArray(l).toString())
    }

    fun add(c: Context, k: String, v: String, max: Int = 200) {
        val l = list(c, k)
        l.add(v)
        while (l.size > max) l.removeAt(0)
        saveList(c, k, l)
    }

    fun log(c: Context, line: String) {
        add(c, "log", line, 40)
    }
}
