package com.helios.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class HeliosNotifs : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || sbn.packageName == packageName || sbn.isOngoing) return
        try {
            val ex = sbn.notification.extras
            val title = ex.getCharSequence("android.title")?.toString() ?: ""
            val text = ex.getCharSequence("android.text")?.toString() ?: ""
            if (title.isBlank() && text.isBlank()) return
            val pm = packageManager
            val app = try {
                pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
            } catch (e: Exception) {
                sbn.packageName
            }
            val line = "$app : $title. $text"
            Store.add(this, "notifs", line, 30)
            if (Store.flag(this, "autoread")) HeliosService.instance?.say(line)
        } catch (e: Exception) {
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val text = i.getStringExtra("text") ?: return
        try {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel("helios_alerts", "Rappels Helios", NotificationManager.IMPORTANCE_HIGH)
            )
            val n = Notification.Builder(c, "helios_alerts")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("HELIOS - Rappel")
                .setContentText(text)
                .setAutoCancel(true)
                .build()
            nm.notify((System.currentTimeMillis() % 100000).toInt(), n)
        } catch (e: Exception) {
        }
        HeliosService.instance?.say("Rappel : $text")
    }
}
