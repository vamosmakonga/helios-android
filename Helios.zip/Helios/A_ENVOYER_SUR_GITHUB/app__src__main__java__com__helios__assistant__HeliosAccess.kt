package com.helios.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class HeliosAccess : AccessibilityService() {

    companion object {
        @Volatile
        var instance: HeliosAccess? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    fun global(action: Int): Boolean {
        return try {
            performGlobalAction(action)
        } catch (e: Exception) {
            false
        }
    }

    private fun walk(n: AccessibilityNodeInfo?, depth: Int, f: (AccessibilityNodeInfo) -> Boolean): Boolean {
        if (n == null || depth > 40) return false
        if (f(n)) return true
        for (i in 0 until n.childCount) {
            if (walk(n.getChild(i), depth + 1, f)) return true
        }
        return false
    }

    fun readScreen(): String {
        val root = rootInActiveWindow ?: return ""
        val out = LinkedHashSet<String>()
        walk(root, 0) { n ->
            val t = (n.text ?: n.contentDescription)?.toString()
            if (!t.isNullOrBlank() && out.size < 40) out.add(t.trim())
            false
        }
        return out.joinToString(". ")
    }

    fun clickLabel(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val q = Act.norm(label).trim()
        if (q.isEmpty()) return false
        return walk(root, 0) { n ->
            val t = Act.norm((n.text ?: n.contentDescription ?: "").toString())
            if (t.isNotEmpty() && t.contains(q)) {
                var p: AccessibilityNodeInfo? = n
                var done = false
                while (p != null && !done) {
                    if (p.isClickable) {
                        done = p.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    }
                    p = p.parent
                }
                done
            } else {
                false
            }
        }
    }

    fun typeText(s: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, s)
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    /** down = true : voir la suite de la page (le doigt monte). */
    fun swipe(down: Boolean): Boolean {
        return try {
            val dm = resources.displayMetrics
            val x = dm.widthPixels / 2f
            val y1 = dm.heightPixels * (if (down) 0.7f else 0.3f)
            val y2 = dm.heightPixels * (if (down) 0.3f else 0.7f)
            val p = Path()
            p.moveTo(x, y1)
            p.lineTo(x, y2)
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(p, 0, 350))
                .build()
            dispatchGesture(g, null, null)
        } catch (e: Exception) {
            false
        }
    }
}
