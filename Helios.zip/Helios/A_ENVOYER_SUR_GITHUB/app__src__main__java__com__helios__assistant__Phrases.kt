package com.helios.assistant

/** Petit dictionnaire français <-> swahili qui fonctionne sans internet. */
object Phrases {

    private val fr2sw: Map<String, String> = mapOf(
        "bonjour" to "jambo",
        "bonsoir" to "habari za jioni",
        "salut" to "mambo",
        "comment allez-vous" to "habari yako",
        "comment vas-tu" to "habari yako",
        "je vais bien" to "niko mzima",
        "merci" to "asante",
        "merci beaucoup" to "asante sana",
        "s'il vous plait" to "tafadhali",
        "oui" to "ndiyo",
        "non" to "hapana",
        "au revoir" to "kwaheri",
        "bienvenue" to "karibu",
        "excusez-moi" to "samahani",
        "pardon" to "samahani",
        "bonne nuit" to "usiku mwema",
        "bonne chance" to "bahati njema",
        "je t'aime" to "nakupenda",
        "je ne comprends pas" to "sielewi",
        "je ne sais pas" to "sijui",
        "aide-moi" to "nisaidie",
        "combien ca coute" to "bei gani",
        "c'est cher" to "ni ghali",
        "ou est" to "wapi",
        "quand" to "lini",
        "pourquoi" to "kwa nini",
        "qui" to "nani",
        "quoi" to "nini",
        "eau" to "maji",
        "nourriture" to "chakula",
        "pain" to "mkate",
        "argent" to "pesa",
        "maison" to "nyumba",
        "ecole" to "shule",
        "travail" to "kazi",
        "ami" to "rafiki",
        "famille" to "familia",
        "mere" to "mama",
        "pere" to "baba",
        "enfant" to "mtoto",
        "homme" to "mwanaume",
        "femme" to "mwanamke",
        "jour" to "siku",
        "nuit" to "usiku",
        "aujourd'hui" to "leo",
        "demain" to "kesho",
        "hier" to "jana",
        "maintenant" to "sasa",
        "beaucoup" to "sana",
        "peu" to "kidogo",
        "bon" to "nzuri",
        "mauvais" to "mbaya",
        "grand" to "kubwa",
        "petit" to "ndogo",
        "un" to "moja",
        "deux" to "mbili",
        "trois" to "tatu",
        "quatre" to "nne",
        "cinq" to "tano",
        "six" to "sita",
        "sept" to "saba",
        "huit" to "nane",
        "neuf" to "tisa",
        "dix" to "kumi"
    )

    private val sw2fr: Map<String, String> = fr2sw.entries.associate { Pair(it.value, it.key) }

    private fun clean(s: String): String =
        Act.norm(s).replace(Regex("[?!.,;]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun convert(q: String, dict: Map<String, String>): String? {
        val whole = dict[q]
        if (whole != null) return whole
        val parts = q.split(" ")
        if (parts.size < 2) return null
        val out = mutableListOf<String>()
        for (w in parts) {
            val x = dict[w] ?: return null
            out.add(x)
        }
        return out.joinToString(" ")
    }

    /** Retourne la traduction, ou null si ce dictionnaire hors ligne ne la connaît pas. */
    fun translate(target: String, text: String): String? {
        val q = clean(text)
        if (q.isEmpty()) return null
        val t = clean(target)
        return when {
            t == "swahili" -> convert(q, fr2sw)?.let { "En swahili : $it" }
            t == "francais" -> convert(q, sw2fr)?.let { "En français : $it" }
            t.isEmpty() -> {
                val a = convert(q, fr2sw)
                if (a != null) "En swahili : $a"
                else convert(q, sw2fr)?.let { "En français : $it" }
            }
            else -> null
        }
    }
}
