package com.helios.assistant

/** Tolérance aux fautes de prononciation / de reconnaissance vocale. */
object Fuzzy {

    private val vocab = listOf(
        "ouvre", "lance", "appelle", "envoie", "alarme", "minuteur", "rappelle", "batterie",
        "lampe", "torche", "volume", "musique", "notifications", "retour", "accueil", "defile",
        "touche", "clique", "calcule", "cherche", "meteo", "whatsapp", "ecris", "verrouille",
        "urgence", "traduis", "photo", "camera", "taches", "bluetooth", "wifi", "parametres",
        "raccroche", "decroche", "itineraire", "desinstalle", "supprime", "efface", "regarde"
    )

    fun lev(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) {
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)
            }
        }
        return d[a.length][b.length]
    }

    /** Remplace chaque mot proche d'une commande connue par cette commande. */
    fun fix(t: String): String {
        val out = t.split(" ").map { w ->
            if (w.length < 4 || w in vocab) {
                w
            } else {
                var best = w
                var bd = 99
                val max = if (w.length <= 5) 1 else 2
                for (v in vocab) {
                    if (v[0] != w[0]) continue
                    val dd = lev(w, v)
                    if (dd <= max && dd < bd) {
                        bd = dd
                        best = v
                    }
                }
                best
            }
        }
        return out.joinToString(" ")
    }

    /** Trouve l'option la plus proche (ex. nom d'application mal prononcé). */
    fun closest(q: String, options: List<String>): String? {
        var best: String? = null
        var bd = 99
        val max = maxOf(1, q.length / 4)
        for (o in options) {
            val d = lev(q, o)
            if (d <= max && d < bd) {
                bd = d
                best = o
            }
        }
        return best
    }
}
