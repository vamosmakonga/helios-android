package com.helios.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.Location
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.provider.ContactsContract
import android.telephony.SmsManager
import java.text.Normalizer
import java.util.Locale

object Act {

    fun norm(s: String): String {
        val n = Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        return n.replace(Regex("\\p{InCombiningDiacriticalMarks}+"), "").replace("’", "'")
    }

    /** Lance une activité, de préférence via le service d'accessibilité (autorisé en arrière-plan). */
    fun go(c: Context, i: Intent): Boolean {
        return try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val a = HeliosAccess.instance
            if (a != null) a.startActivity(i) else c.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun online(c: Context): Boolean {
        return try {
            val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val n = cm.activeNetwork ?: return false
            val cap = cm.getNetworkCapabilities(n) ?: return false
            cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            false
        }
    }

    fun granted(c: Context, perm: String): Boolean =
        c.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    fun contact(c: Context, name: String): Pair<String, String>? {
        if (!granted(c, Manifest.permission.READ_CONTACTS)) return null
        val q = norm(name).trim()
        if (q.isEmpty()) return null
        var best: Pair<String, String>? = null
        var score = 0
        try {
            val cur = c.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null, null
            )
            if (cur != null) {
                while (cur.moveToNext()) {
                    val n = cur.getString(0) ?: continue
                    val num = cur.getString(1) ?: continue
                    val nn = norm(n)
                    val s = when {
                        nn == q -> 3
                        nn.startsWith(q) -> 2
                        nn.contains(q) -> 1
                        else -> 0
                    }
                    if (s > score) {
                        score = s
                        best = Pair(n, num)
                    }
                }
                cur.close()
            }
        } catch (e: Exception) {
        }
        return best
    }

    /** Numéro au format international sans + (pour wa.me). */
    fun intl(num: String): String {
        var d = num.filter { it.isDigit() || it == '+' }
        if (d.startsWith("+")) return d.substring(1)
        if (d.startsWith("00")) return d.substring(2)
        if (d.startsWith("0")) d = Store.COUNTRY_CODE + d.substring(1)
        return d
    }

    @Suppress("DEPRECATION")
    private fun smsManager(c: Context): SmsManager {
        return if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java)
        else SmsManager.getDefault()
    }

    fun sms(c: Context, num: String, text: String): Boolean {
        return try {
            val sm = smsManager(c)
            val parts = sm.divideMessage(text)
            sm.sendMultipartTextMessage(num, null, parts, null, null)
            true
        } catch (e: Exception) {
            false
        }
    }

    var torchOn = false

    fun torch(c: Context, on: Boolean): Boolean {
        return try {
            val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            var id: String? = null
            for (x in cm.cameraIdList) {
                val f = cm.getCameraCharacteristics(x).get(CameraCharacteristics.FLASH_INFO_AVAILABLE)
                if (f == true) {
                    id = x
                    break
                }
            }
            if (id == null) {
                false
            } else {
                cm.setTorchMode(id, on)
                torchOn = on
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    fun battery(c: Context): Int {
        val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    /** Retourne (nom affiché, package) de l'appli la plus proche du nom demandé. */
    fun findApp(c: Context, q: String): Pair<String, String>? {
        val nq = norm(q).trim()
        if (nq.isEmpty()) return null
        val pm = c.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(i, 0)
        var best: Pair<String, String>? = null
        var score = 0
        for (r in list) {
            val raw = r.loadLabel(pm).toString()
            val label = norm(raw)
            val s = when {
                label == nq -> 4
                label.startsWith(nq) -> 3
                label.contains(nq) -> 2
                label.length > 2 && nq.contains(label) -> 1
                else -> 0
            }
            if (s > score) {
                score = s
                best = Pair(raw, r.activityInfo.packageName)
            }
        }
        if (best == null) {
            // Nom mal prononcé : on prend l'application dont le nom ressemble le plus.
            val map = HashMap<String, Pair<String, String>>()
            for (r in list) {
                val raw = r.loadLabel(pm).toString()
                map[norm(raw)] = Pair(raw, r.activityInfo.packageName)
            }
            val k = Fuzzy.closest(nq, map.keys.toList())
            if (k != null) best = map[k]
        }
        return best
    }

    fun lastLocationLink(c: Context): String? {
        if (!granted(c, Manifest.permission.ACCESS_FINE_LOCATION)) return null
        return try {
            val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            var best: Location? = null
            for (p in lm.getProviders(true)) {
                val l = lm.getLastKnownLocation(p) ?: continue
                val b = best
                if (b == null || l.accuracy < b.accuracy) best = l
            }
            val r = best
            if (r == null) null else "https://maps.google.com/?q=${r.latitude},${r.longitude}"
        } catch (e: Exception) {
            null
        }
    }
}

/** Petit calculateur : + - * / et parenthèses. */
class Calc(private val s: String) {
    private var p = 0

    fun parse(): Double {
        val v = expr()
        if (p < s.length) throw IllegalArgumentException("fin inattendue")
        return v
    }

    private fun peek(): Char = if (p < s.length) s[p] else '\u0000'

    private fun expr(): Double {
        var v = term()
        while (peek() == '+' || peek() == '-') {
            val o = s[p++]
            val r = term()
            v = if (o == '+') v + r else v - r
        }
        return v
    }

    private fun term(): Double {
        var v = factor()
        while (peek() == '*' || peek() == '/') {
            val o = s[p++]
            val r = factor()
            v = if (o == '*') v * r else v / r
        }
        return v
    }

    private fun factor(): Double {
        if (peek() == '-') {
            p++
            return -factor()
        }
        if (peek() == '(') {
            p++
            val v = expr()
            if (peek() == ')') p++
            return v
        }
        val st = p
        while (peek().isDigit() || peek() == '.') p++
        if (st == p) throw IllegalArgumentException("nombre attendu")
        return s.substring(st, p).toDouble()
    }
}
