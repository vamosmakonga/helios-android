#!/bin/bash
# Remet chaque fichier "a__b__c.ext" à sa place "a/b/c.ext".
# Utile quand on envoie les fichiers à plat sur GitHub depuis un téléphone.
for f in *__*; do
  [ -f "$f" ] || continue
  dest="${f//__//}"
  mkdir -p "$(dirname "$dest")"
  mv "$f" "$dest"
done
echo "Fichiers rangés."
