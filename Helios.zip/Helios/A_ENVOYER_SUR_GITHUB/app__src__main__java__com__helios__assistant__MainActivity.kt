package com.helios.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val h = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var input: EditText

    private val refresher = object : Runnable {
        override fun run() {
            refresh()
            h.postDelayed(this, 2000)
        }
    }

    private fun dp(x: Int): Int = (x * resources.displayMetrics.density).toInt()

    private fun button(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.parseColor("#001018"))
        b.setBackgroundColor(Color.parseColor("#27D3F5"))
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(8)
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(24), dp(16), dp(24))
        root.setBackgroundColor(Color.parseColor("#050B14"))

        val title = TextView(this)
        title.text = "HELIOS"
        title.textSize = 34f
        title.gravity = Gravity.CENTER
        title.setTextColor(Color.parseColor("#27D3F5"))
        root.addView(title)

        val sub = TextView(this)
        sub.text = "Assistant vocal · hors ligne d'abord"
        sub.gravity = Gravity.CENTER
        sub.setTextColor(Color.parseColor("#8FA3B5"))
        root.addView(sub)

        status = TextView(this)
        status.setTextColor(Color.WHITE)
        status.textSize = 15f
        status.setPadding(0, dp(16), 0, dp(8))
        root.addView(status)

        root.addView(button("1. Autoriser micro, contacts, SMS, appels, position") { askPermissions() })
        root.addView(button("2. Activer l'accessibilité (contrôle du téléphone)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            toast("Cherchez HELIOS dans la liste puis activez-le.")
        })
        root.addView(button("3. Activer l'accès aux notifications") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(button("4. Autoriser l'affichage par-dessus les autres applis") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("5. Batterie : ne pas restreindre Helios") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            toast("Choisissez Toutes les applis, HELIOS, puis Ne pas optimiser.")
        })
        root.addView(button("▶ Démarrer Helios") {
            if (!Act.granted(this, Manifest.permission.RECORD_AUDIO)) {
                toast("Autorisez d'abord le micro (bouton 1).")
                askPermissions()
            } else {
                try {
                    HeliosService.start(this)
                    toast("Helios démarre. Dites : Bonjour Helios")
                } catch (e: Exception) {
                    toast("Impossible de démarrer : " + e.message)
                }
            }
        })
        root.addView(button("■ Arrêter Helios") { HeliosService.stop(this) })

        input = EditText(this)
        input.hint = "Ou tapez une commande ici"
        input.setHintTextColor(Color.parseColor("#6B7C8C"))
        input.setTextColor(Color.WHITE)
        input.inputType = InputType.TYPE_CLASS_TEXT
        root.addView(input)
        root.addView(button("Envoyer la commande") {
            val txt = input.text.toString().trim()
            if (txt.isNotEmpty()) {
                input.setText("")
                val s = HeliosService.instance
                if (s != null) {
                    s.runTyped(txt)
                } else {
                    Store.log(this, "Vous : $txt")
                    Engine.handle(this, txt) { r ->
                        Store.log(this, "Helios : $r")
                        toast(r)
                    }
                }
                refresh()
            }
        })

        log = TextView(this)
        log.setTextColor(Color.parseColor("#BFD0DE"))
        log.textSize = 14f
        log.setPadding(0, dp(16), 0, 0)
        root.addView(log)

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    private fun askPermissions() {
        val p = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ANSWER_PHONE_CALLS,
            Manifest.permission.CAMERA
        )
        if (Build.VERSION.SDK_INT >= 33) p.add("android.permission.POST_NOTIFICATIONS")
        requestPermissions(p.toTypedArray(), 1)
    }

    private fun ok(b: Boolean): String = if (b) "✔" else "✘"

    private fun refresh() {
        val mic = Act.granted(this, Manifest.permission.RECORD_AUDIO)
        val acc = HeliosAccess.instance != null
        val nl = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        val ov = Settings.canDrawOverlays(this)
        val on = HeliosService.instance != null
        status.text = "${ok(mic)} Micro et permissions\n" +
            "${ok(acc)} Accessibilité (contrôle du téléphone)\n" +
            "${ok(nl)} Accès aux notifications\n" +
            "${ok(ov)} Affichage par-dessus\n" +
            "${ok(on)} Helios " + (if (on) "à l'écoute" else "arrêté") + "\n" +
            "Internet : " + (if (Act.online(this)) "connecté" else "hors ligne (tout fonctionne)")
        val l = Store.list(this, "log").takeLast(12)
        log.text = if (l.isEmpty()) "Dites : Bonjour Helios, que peux-tu faire ?" else l.joinToString("\n")
    }

    override fun onResume() {
        super.onResume()
        h.post(refresher)
    }

    override fun onPause() {
        h.removeCallbacks(refresher)
        super.onPause()
    }
}
