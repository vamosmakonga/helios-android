# HELIOS — assistant vocal Android

Helios écoute en continu (même téléphone posé sur la table, écran éteint), comprend le **français** et le **swahili**, fonctionne **hors ligne** et n'utilise Internet que lorsqu'il est connecté.

## Installer (depuis votre téléphone, sans ordinateur)

**Méthode la plus simple (GitHub accepte le ZIP, et la compilation l'ouvre toute seule) :**
- Sur GitHub : **Add file → Upload files**, envoyez `Helios.zip` tel quel (sans le dézipper), **Commit changes**.
- Puis **Add file → Create new file**, nom `.github/workflows/build.yml`, collez le contenu de `build.yml` (fourni à part, aussi dans le ZIP), **Commit changes**. Allez ensuite à l'étape 5 ci-dessous.

**Méthode à plat (si la première ne marche pas) :**

1. Dézippez `Helios.zip` avec l'application Fichiers.
2. Sur github.com, ouvrez votre dépôt vide → **Add file → Upload files**.
3. Envoyez **tous les fichiers du dossier `A_ENVOYER_SUR_GITHUB`** (sélection multiple). Validez avec **Commit changes**.
4. Le fichier de compilation `build.yml` est déjà prêt dans le ZIP (à la racine de `Helios` et dans `A_ENVOYER_SUR_GITHUB`). GitHub exige qu'il soit dans `.github/workflows/`, ce que le téléphone ne sait pas envoyer. Donc : sur GitHub, **Add file → Create new file**, tapez dans le nom `.github/workflows/build.yml` (les `/` créent les dossiers), ouvrez `build.yml` du ZIP, copiez tout, collez, puis **Commit changes**.
5. Onglet **Actions** : la compilation démarre seule (5 à 10 minutes). Quand elle est verte, ouvrez-la, descendez à **Artifacts**, téléchargez **Helios-APK**, dézippez, installez `app-debug.apk` (autorisez « sources inconnues »).
6. Si la compilation affiche une erreur rouge, copiez-moi le message de l'étape « Compiler l'APK » et je corrige.

## Premier lancement (important, dans cet ordre)

Ouvrez Helios et touchez les boutons 1 à 5 :
1. Permissions (micro, contacts, SMS, appels, position, notifications).
2. **Accessibilité** : c'est ce qui permet à Helios de toucher, défiler, écrire et revenir en arrière.
3. Accès aux notifications.
4. Affichage par-dessus les autres applis (nécessaire pour ouvrir des applis quand l'écran est éteint).
5. Batterie : « Ne pas optimiser » (Tecno/Infinix/itel tuent sinon les applis en arrière-plan ; dans les paramètres, autorisez aussi le démarrage automatique et verrouillez Helios dans les applis récentes).

Puis **▶ Démarrer Helios** et dites : **« Bonjour Helios »**.

## Hors ligne : télécharger la langue vocale

Paramètres → Google → Paramètres des applications Google → Recherche, Assistant et voix → Voix → **Reconnaissance vocale hors connexion** → téléchargez **Français** (et **Swahili**). Sans cela, la reconnaissance vocale demande Internet.

## Exemples de commandes

- « Bonjour Helios, ouvre WhatsApp » · « ouvre Facebook »
- « appelle Maman » · « envoie un SMS à Papa disant je rentre ce soir » · « envoie un message WhatsApp à Jean disant bonjour »
- « alarme à 6 heures 30 » · « minuteur 10 minutes » · « rappelle-moi de payer le loyer dans 2 heures »
- « note : acheter du sucre » · « mes notes » · « ajoute une tâche : appeler le fournisseur »
- « allume la lampe » · « monte le volume » · « musique suivante » · « batterie »
- « lis mes notifications » · « active la lecture automatique des notifications »
- « lis l'écran » · « touche Envoyer » · « défile vers le bas » · « retour » · « accueil » · « capture d'écran » · « verrouille le téléphone »
- « écris bonjour » (dans le champ de texte sélectionné)
- « calcule 125 fois 4 plus 20 » (hors ligne)
- « traduis en swahili merci » · « traduis en français kwaheri » (mots et phrases courantes, hors ligne)
- « cherche prix du maïs » · « météo » · « traduis en anglais bonjour » · « itinéraire vers le marché » (si connecté)
- « mon contact d'urgence est Maman » puis « urgence » (envoie votre position par SMS)
- **Vision par caméra** (hors ligne) : « que vois-tu ? » (décrit les objets devant la caméra arrière), « regarde-moi » (caméra avant), « lis le texte » (lit à voix haute un texte ou un document placé devant la caméra)
- Corrections : « ouvre Facebook, je voulais dire WhatsApp » (Helios garde la fin) · un nom d'appli mal prononcé est rapproché de l'appli la plus proche
- « parle swahili » / « parle français » · « que peux-tu faire »

## Sécurité

Appels, SMS, WhatsApp, alerte d'urgence, désinstallation et effacement demandent toujours votre confirmation : Helios répète l'action, vous dites « oui » ou « non ».

## Limites honnêtes

- Android 14 interdit à toute application d'activer le Wi-Fi, le Bluetooth ou le mode avion directement : Helios ouvre le bon réglage, et vous pouvez dire « touche Wi-Fi ».
- Il peut y avoir un petit bip à chaque cycle d'écoute selon le téléphone (c'est le moteur vocal de Google).
- Traduction hors ligne : seulement un dictionnaire français ↔ swahili de mots et phrases courantes ; le reste demande Internet.
- Vision : l'application grossit (modèles inclus, environ 30 Mo de plus). Les objets sont nommés en français pour les plus courants, sinon en anglais. Elle ne reconnaît pas les personnes. La caméra ne s'utilise que sur votre commande, jamais en continu. Selon le téléphone, la caméra peut refuser de démarrer écran éteint ; Helios vous le dit.
- Helios ne lit pas les pensées : il comprend ce que vous dites, avec une tolérance aux petites fautes de prononciation.
- Pas de maison connectée dans cette version.
- Le numéro commençant par 0 reçoit l'indicatif 243 : modifiable dans `Store.kt` (`COUNTRY_CODE`).
- Je n'ai pas pu compiler le projet de mon côté : la première compilation sur GitHub peut demander un ajustement.
