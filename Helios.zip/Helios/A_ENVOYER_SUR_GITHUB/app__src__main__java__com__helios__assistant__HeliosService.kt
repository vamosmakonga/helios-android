package com.helios.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class HeliosService : Service() {

    companion object {
        @Volatile
        var instance: HeliosService? = null

        private const val CH = "helios_service"

        fun start(c: Context) {
            c.startForegroundService(Intent(c, HeliosService::class.java))
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, HeliosService::class.java))
        }
    }

    private val h = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val queue = mutableListOf<String>()
    private var pendingUtt = 0
    private var running = false
    private var listening = false
    private var activeUntil = 0L
    private var warnedOffline = false
    private var wake: PowerManager.WakeLock? = null

    private val wakeRegex =
        Regex("(?i)(?:bonjour|salut|bonsoir|hello|hey|ok|jambo)?\\s*\\bh?[eéè]l[iy]o[sz]?\\b")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        instance = this
        running = true
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CH, "Helios", NotificationManager.IMPORTANCE_LOW))
            val open = PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            val n = Notification.Builder(this, CH)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("HELIOS")
                .setContentText("Helios est à l'écoute. Dites : Bonjour Helios")
                .setContentIntent(open)
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 30) {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                if (Act.granted(this, Manifest.permission.CAMERA)) {
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                }
                startForeground(1, n, type)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            Store.log(this, "Erreur démarrage : " + e.message)
            stopSelf()
            return
        }
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "helios:listen")
            wake?.acquire(12 * 60 * 60 * 1000L)
        } catch (e: Exception) {
        }
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.setPitch(0.8f)
                tts?.setSpeechRate(1.0f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        h.post { uttFinished() }
                    }

                    override fun onError(utteranceId: String?) {
                        h.post { uttFinished() }
                    }
                })
                applyLang()
                val q = queue.toList()
                queue.clear()
                for (s in q) speakNow(s)
                if (q.isEmpty()) {
                    say(
                        if (Store.lang(this) == "sw") "Helios iko tayari. Niambie unataka nini."
                        else "Helios est prêt. Dites : Bonjour Helios."
                    )
                }
            } else {
                Store.log(this, "Synthèse vocale indisponible. Installez Google Text-to-Speech.")
            }
        }
        initRecognizer()
        startListening()
    }

    private fun initRecognizer() {
        try {
            rec?.destroy()
        } catch (e: Exception) {
        }
        rec = null
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Store.log(this, "Reconnaissance vocale indisponible. Installez l'application Google.")
            return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                listening = false
                var delay = 300L
                when (error) {
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> delay = 1500L
                    SpeechRecognizer.ERROR_CLIENT -> {
                        delay = 800L
                        h.post { initRecognizer() }
                    }
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                        Store.log(this@HeliosService, "Permission micro manquante.")
                        stopSelf()
                        return
                    }
                    12, 13 -> {
                        delay = 5000L
                        if (!warnedOffline) {
                            warnedOffline = true
                            say("Le pack vocal hors ligne n'est pas installé. Ouvrez les paramètres Google, reconnaissance vocale hors ligne, et téléchargez la langue.")
                        }
                    }
                }
                if (pendingUtt == 0) h.postDelayed({ startListening() }, delay)
            }

            override fun onResults(results: Bundle?) {
                listening = false
                val l = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = l?.firstOrNull()
                if (!text.isNullOrBlank()) process(text)
                if (pendingUtt == 0) h.postDelayed({ startListening() }, 250)
            }
        })
        rec = r
    }

    private fun startListening() {
        if (!running || pendingUtt > 0 || listening) return
        if (!Act.granted(this, Manifest.permission.RECORD_AUDIO)) return
        val r = rec ?: return
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(
            RecognizerIntent.EXTRA_LANGUAGE,
            if (Store.lang(this) == "sw") "sw-KE" else "fr-FR"
        )
        i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        try {
            r.startListening(i)
            listening = true
        } catch (e: Exception) {
            listening = false
            h.postDelayed({ startListening() }, 1500)
        }
    }

    private fun process(text: String) {
        Store.log(this, "Vous : $text")
        val now = System.currentTimeMillis()
        val hasWake = wakeRegex.containsMatchIn(text)
        if (hasWake) {
            val cleaned = wakeRegex.replace(text, " ").trim()
            activeUntil = now + 12000
            if (cleaned.isBlank()) {
                say(if (Store.lang(this) == "sw") "Ndiyo, nakusikiliza." else "Oui, je vous écoute.")
            } else {
                run(cleaned)
            }
        } else if (now < activeUntil) {
            run(text)
        }
    }

    private fun run(text: String) {
        try {
            Engine.handle(this, text) { say(it) }
        } catch (e: Exception) {
            say("Une erreur est survenue, mais je reste actif.")
        }
        val now = System.currentTimeMillis()
        activeUntil = if (Engine.pending != null) now + 15000 else now + 8000
    }

    /** Commande tapée au clavier depuis l'écran principal. */
    fun runTyped(text: String) {
        h.post {
            Store.log(this, "Vous : $text")
            run(text)
        }
    }

    fun say(text: String) {
        h.post {
            Store.log(this, "Helios : $text")
            if (!ttsReady) {
                queue.add(text)
            } else {
                speakNow(text)
            }
        }
    }

    private fun speakNow(text: String) {
        pendingUtt++
        try {
            rec?.cancel()
        } catch (e: Exception) {
        }
        listening = false
        val r = tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "h" + System.nanoTime())
        if (r != TextToSpeech.SUCCESS) {
            pendingUtt = maxOf(0, pendingUtt - 1)
            if (pendingUtt == 0) h.postDelayed({ startListening() }, 400)
        }
    }

    private fun uttFinished() {
        pendingUtt = maxOf(0, pendingUtt - 1)
        if (pendingUtt == 0) {
            val now = System.currentTimeMillis()
            if (Engine.pending != null) activeUntil = now + 15000
            h.postDelayed({ startListening() }, 400)
        }
    }

    fun stopSpeaking() {
        h.post {
            try {
                tts?.stop()
            } catch (e: Exception) {
            }
            pendingUtt = 0
            h.postDelayed({ startListening() }, 300)
        }
    }

    fun applyLang() {
        val sw = Store.lang(this) == "sw"
        val loc = if (sw) Locale("sw", "KE") else Locale.FRANCE
        val r = tts?.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.setLanguage(Locale.FRANCE)
        }
        try {
            rec?.cancel()
        } catch (e: Exception) {
        }
        listening = false
        h.postDelayed({ startListening() }, 500)
    }

    override fun onDestroy() {
        running = false
        instance = null
        h.removeCallbacksAndMessages(null)
        try {
            rec?.destroy()
        } catch (e: Exception) {
        }
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
        }
        try {
            wake?.release()
        } catch (e: Exception) {
        }
        super.onDestroy()
    }
}
