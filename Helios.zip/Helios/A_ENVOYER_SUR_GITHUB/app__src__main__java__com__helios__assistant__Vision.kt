package com.helios.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.Looper
import android.view.Surface
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** Vision par caméra, entièrement sur le téléphone (modèles ML Kit inclus, sans internet). */
object Vision {

    private val h = Handler(Looper.getMainLooper())

    private val fr = mapOf(
        "person" to "une personne", "face" to "un visage", "smile" to "un sourire", "hair" to "des cheveux",
        "skin" to "de la peau", "hand" to "une main", "finger" to "un doigt", "table" to "une table",
        "chair" to "une chaise", "furniture" to "un meuble", "room" to "une pièce", "wall" to "un mur",
        "ceiling" to "un plafond", "floor" to "le sol", "window" to "une fenêtre", "door" to "une porte",
        "plant" to "une plante", "tree" to "un arbre", "flower" to "une fleur", "cat" to "un chat",
        "dog" to "un chien", "bird" to "un oiseau", "car" to "une voiture", "vehicle" to "un véhicule",
        "building" to "un bâtiment", "sky" to "le ciel", "cloud" to "des nuages", "food" to "de la nourriture",
        "fruit" to "un fruit", "drink" to "une boisson", "bottle" to "une bouteille", "book" to "un livre",
        "paper" to "du papier", "text" to "du texte", "phone" to "un téléphone", "mobile phone" to "un téléphone",
        "computer" to "un ordinateur", "laptop" to "un ordinateur portable", "shoe" to "une chaussure",
        "clothing" to "un vêtement", "hat" to "un chapeau", "glasses" to "des lunettes", "cup" to "une tasse",
        "plate" to "une assiette", "bed" to "un lit", "couch" to "un canapé", "light" to "une lumière",
        "lamp" to "une lampe", "water" to "de l'eau", "road" to "une route", "street" to "une rue",
        "grass" to "de l'herbe", "mountain" to "une montagne", "bicycle" to "un vélo",
        "motorcycle" to "une moto", "television" to "une télévision", "wood" to "du bois", "bag" to "un sac",
        "money" to "de l'argent", "box" to "une boîte", "tableware" to "de la vaisselle", "kitchen" to "une cuisine"
    )

    private fun frName(en: String): String = fr[en.lowercase()] ?: en

    /**
     * Prend une image avec la caméra puis l'analyse.
     * ocr = true : lit le texte ; sinon décrit ce qui est visible.
     */
    @SuppressLint("MissingPermission")
    fun run(c: Context, front: Boolean, ocr: Boolean, say: (String) -> Unit) {
        if (!Act.granted(c, Manifest.permission.CAMERA)) {
            say("Autorisez d'abord la caméra dans l'application, bouton 1.")
            return
        }
        val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        var camId: String? = null
        var sensor = 90
        var w = 0
        var hgt = 0
        try {
            val want = if (front) CameraCharacteristics.LENS_FACING_FRONT else CameraCharacteristics.LENS_FACING_BACK
            for (id in cm.cameraIdList) {
                val ch = cm.getCameraCharacteristics(id)
                if (ch.get(CameraCharacteristics.LENS_FACING) != want) continue
                val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: continue
                val sizes = map.getOutputSizes(ImageFormat.YUV_420_888) ?: continue
                val pick = sizes.filter { it.width <= 1920 }.maxByOrNull { it.width * it.height } ?: continue
                camId = id
                sensor = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
                w = pick.width
                hgt = pick.height
                break
            }
        } catch (e: Exception) {
            say("La caméra est indisponible.")
            return
        }
        val id = camId
        if (id == null || w == 0) {
            say("Je ne trouve pas la caméra demandée.")
            return
        }

        val reader = ImageReader.newInstance(w, hgt, ImageFormat.YUV_420_888, 2)
        var device: CameraDevice? = null
        var frames = 0
        var done = false

        fun closeAll() {
            try {
                device?.close()
            } catch (e: Exception) {
            }
            try {
                reader.close()
            } catch (e: Exception) {
            }
        }

        fun fail() {
            if (!done) {
                done = true
                closeAll()
                say("La caméra n'a pas pu démarrer. Fermez les autres applications qui l'utilisent.")
            }
        }

        reader.setOnImageAvailableListener({ r ->
            val img = try {
                r.acquireLatestImage()
            } catch (e: Exception) {
                null
            }
            if (img != null) {
                frames++
                if (done || frames < 12) {
                    img.close()
                } else {
                    done = true
                    analyze(img, sensor, ocr, say) { closeAll() }
                }
            }
        }, h)

        h.postDelayed({
            if (!done) {
                done = true
                closeAll()
                say("Je n'ai pas réussi à prendre d'image. L'écran doit parfois être allumé pour utiliser la caméra.")
            }
        }, 9000)

        try {
            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    device = camera
                    try {
                        val req = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                        req.addTarget(reader.surface)
                        req.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                        val built = req.build()
                        openSession(camera, reader.surface, built, { fail() })
                    } catch (e: Exception) {
                        fail()
                    }
                }

                override fun onDisconnected(camera: CameraDevice) {
                    camera.close()
                }

                override fun onError(camera: CameraDevice, error: Int) {
                    camera.close()
                    fail()
                }
            }, h)
        } catch (e: Exception) {
            fail()
        }
    }

    @Suppress("DEPRECATION")
    private fun openSession(camera: CameraDevice, target: Surface, req: CaptureRequest, onFail: () -> Unit) {
        try {
            camera.createCaptureSession(listOf(target), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    try {
                        session.setRepeatingRequest(req, null, h)
                    } catch (e: Exception) {
                        onFail()
                    }
                }

                override fun onConfigureFailed(session: CameraCaptureSession) {
                    onFail()
                }
            }, h)
        } catch (e: Exception) {
            onFail()
        }
    }

    private fun analyze(img: Image, rotation: Int, ocr: Boolean, say: (String) -> Unit, finish: () -> Unit) {
        try {
            val input = InputImage.fromMediaImage(img, rotation)
            if (ocr) {
                val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                rec.process(input)
                    .addOnSuccessListener { t ->
                        val s = t.text.replace("\n", " ").trim()
                        say(if (s.isEmpty()) "Je ne vois aucun texte lisible." else "Je lis : " + s.take(600))
                    }
                    .addOnFailureListener { say("La lecture du texte a échoué.") }
                    .addOnCompleteListener {
                        try {
                            img.close()
                        } catch (e: Exception) {
                        }
                        finish()
                    }
            } else {
                val lab = ImageLabeling.getClient(
                    ImageLabelerOptions.Builder().setConfidenceThreshold(0.6f).build()
                )
                lab.process(input)
                    .addOnSuccessListener { l ->
                        val names = l.take(5).map { frName(it.text) }
                        say(
                            if (names.isEmpty()) "Je ne reconnais rien de précis."
                            else "Je vois : " + names.joinToString(", ") + "."
                        )
                    }
                    .addOnFailureListener { say("L'analyse de l'image a échoué.") }
                    .addOnCompleteListener {
                        try {
                            img.close()
                        } catch (e: Exception) {
                        }
                        finish()
                    }
            }
        } catch (e: Exception) {
            try {
                img.close()
            } catch (x: Exception) {
            }
            finish()
            say("L'analyse de l'image a échoué.")
        }
    }
}
