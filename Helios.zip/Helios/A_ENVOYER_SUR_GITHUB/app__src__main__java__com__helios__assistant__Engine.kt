package com.helios.assistant

import android.accessibilityservice.AccessibilityService
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.telecom.TelecomManager
import android.view.KeyEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Engine {

    /** Action en attente de confirmation (appel, SMS, urgence, suppression...). */
    @Volatile
    var pending: (() -> Unit)? = null

    private val h = Handler(Looper.getMainLooper())

    private var retrying = false

    private fun any(t: String, vararg k: String): Boolean = k.any { t.contains(it) }

    private fun resolve(c: Context, name: String): Pair<String, String>? {
        val d = name.filter { it.isDigit() || it == '+' }
        if (d.count { it.isDigit() } >= 8) return Pair(d, d)
        return Act.contact(c, name.trim())
    }

    private fun enc(s: String): String = Uri.encode(s)

    private fun mediaKey(c: Context, code: Int) {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    fun handle(c: Context, raw: String, say: (String) -> Unit) {
        val t = Act.norm(raw)
            .replace(Regex("[?!.,;]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (t.isEmpty()) return

        // Auto-correction : « ouvre Facebook, je voulais dire WhatsApp » -> on garde la fin.
        val fixM = Regex("(?i).*\\b(?:je voulais dire|je veux dire|plutôt|plutot|namaanisha)\\s+(.+)$").find(raw)
        if (fixM != null && fixM.groupValues[1].isNotBlank()) {
            handle(c, fixM.groupValues[1], say)
            return
        }
        val sw = Store.lang(c) == "sw"
        fun tr(fr: String, s: String = fr): String = if (sw) s else fr
        val words = t.split(" ").toSet()

        fun acc(): HeliosAccess? {
            val a = HeliosAccess.instance
            if (a == null) {
                say(
                    tr(
                        "Activez d'abord l'accessibilité de Helios depuis son écran principal.",
                        "Washa kwanza ufikivu wa Helios kwenye skrini kuu."
                    )
                )
            }
            return a
        }

        // ---- Confirmation en attente ----
        val p = pending
        if (p != null) {
            pending = null
            if (words.any { it in setOf("oui", "ndiyo", "confirme", "ok", "daccord") } ||
                any(t, "d'accord", "vas y", "fais le")
            ) {
                p()
                return
            }
            if (words.any { it in setOf("non", "hapana", "annule", "stop") } ||
                any(t, "laisse tomber")
            ) {
                say(tr("D'accord, j'annule.", "Sawa, nimeghairi."))
                return
            }
        }

        // ---- Langue ----
        if (any(t, "parle swahili", "ongea kiswahili", "passe en swahili")) {
            Store.put(c, "lang", "sw")
            HeliosService.instance?.applyLang()
            say("Sawa. Sasa ninaongea Kiswahili.")
            return
        }
        if (any(t, "parle francais", "ongea kifaransa", "passe en francais")) {
            Store.put(c, "lang", "fr")
            HeliosService.instance?.applyLang()
            say("D'accord. Je parle français.")
            return
        }

        // ---- Aide ----
        if (any(t, "que peux", "que sais", "tes fonctions", "tes capacites", "liste des commandes", "unaweza kufanya")) {
            say(
                tr(
                    "Je peux ouvrir vos applications, appeler, envoyer des SMS et des messages WhatsApp, régler alarmes, minuteurs et rappels, prendre des notes et des tâches, lire vos notifications et l'écran, toucher, défiler, écrire du texte, contrôler lampe, volume et musique, calculer, chercher sur internet quand vous êtes connecté, et envoyer une alerte d'urgence. Par exemple : ouvre WhatsApp.",
                    "Naweza kufungua programu, kupiga simu, kutuma SMS na WhatsApp, kuweka kengele, kusoma arifa na skrini, kubonyeza, kuandika, kukokotoa, na kutuma ujumbe wa dharura."
                )
            )
            return
        }

        // ---- Silence ----
        if (any(t, "tais toi", "nyamaza", "arrete de parler")) {
            HeliosService.instance?.stopSpeaking()
            return
        }

        // ---- Contact d'urgence ----
        if (any(t, "contact d'urgence", "contact durgence")) {
            val name = t.substringAfter("urgence").replace(Regex("^\\s*(est|c'est|:)\\s*"), "").trim()
            val ct = resolve(c, name)
            if (ct == null) {
                say(tr("Je ne trouve pas ce contact.", "Sipati mwasiliani huyo."))
            } else {
                Store.put(c, "emerg_name", ct.first)
                Store.put(c, "emerg_num", ct.second)
                say(tr("Contact d'urgence enregistré : ${ct.first}.", "Mwasiliani wa dharura amehifadhiwa: ${ct.first}."))
            }
            return
        }

        // ---- Urgence ----
        if (any(t, "au secours", "msaada wa haraka") || words.contains("sos") ||
            (words.contains("urgence") && !t.contains("contact"))
        ) {
            val num = Store.get(c, "emerg_num")
            val nm = Store.get(c, "emerg_name")
            if (num.isBlank()) {
                say(tr("Aucun contact d'urgence. Dites : mon contact d'urgence est, puis le nom.", "Hakuna mwasiliani wa dharura."))
                return
            }
            pending = {
                val link = Act.lastLocationLink(c)
                val msg = "URGENCE : j'ai besoin d'aide." + (if (link != null) " Ma position : $link" else "")
                val ok = Act.sms(c, Act.intl(num).let { "+$it" }, msg)
                say(
                    if (ok) tr("Alerte envoyée à $nm.", "Ujumbe wa dharura umetumwa kwa $nm.")
                    else tr("Impossible d'envoyer l'alerte. Vérifiez la permission SMS.", "Imeshindikana kutuma. Angalia ruhusa ya SMS.")
                )
            }
            say(tr("Alerte d'urgence : j'envoie votre position à $nm. Confirmez ?", "Dharura: nitatuma eneo lako kwa $nm. Unathibitisha?"))
            return
        }

        // ---- Heure / date / batterie ----
        if (any(t, "quelle heure", "l'heure", "heure est", "saa ngapi")) {
            val f = SimpleDateFormat("H 'heures' mm", Locale.FRANCE)
            say(tr("Il est " + f.format(Date()) + ".", "Ni saa " + SimpleDateFormat("H:mm", Locale.US).format(Date()) + "."))
            return
        }
        if (any(t, "quel jour", "la date", "quelle date", "tarehe")) {
            say(SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRANCE).format(Date()))
            return
        }
        if (any(t, "batterie", "betri")) {
            say(tr("La batterie est à ${Act.battery(c)} pour cent.", "Betri iko asilimia ${Act.battery(c)}."))
            return
        }

        // ---- Lampe torche ----
        if (any(t, "lampe", "torche", "flash", "tochi")) {
            val off = any(t, "eteins", "eteint", "coupe", "ferme", "zima")
            val ok = Act.torch(c, !off)
            say(
                if (ok) tr(if (off) "Lampe éteinte." else "Lampe allumée.", if (off) "Tochi imezimwa." else "Tochi imewashwa.")
                else tr("Je n'ai pas pu utiliser la lampe.", "Imeshindikana kutumia tochi.")
            )
            return
        }

        // ---- Volume ----
        if (any(t, "volume", "plus fort", "moins fort", "sauti", "coupe le son")) {
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val s = AudioManager.STREAM_MUSIC
            when {
                any(t, "muet", "coupe le son", "nyamazisha") ->
                    am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                any(t, "maximum", "a fond") ->
                    am.setStreamVolume(s, am.getStreamMaxVolume(s), AudioManager.FLAG_SHOW_UI)
                any(t, "baisse", "diminue", "moins fort", "punguza") ->
                    repeat(3) { am.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }
                else ->
                    repeat(3) { am.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }
            }
            say(tr("C'est fait.", "Imekamilika."))
            return
        }

        // ---- Musique (touches média) ----
        val music = any(t, "musique", "chanson", "morceau", "piste", "muziki")
        if (music || t in setOf("pause", "suivant", "precedent", "reprends", "play")) {
            val code = when {
                any(t, "suivant", "suivante", "prochaine", "inayofuata") -> KeyEvent.KEYCODE_MEDIA_NEXT
                any(t, "precedent", "precedente", "iliyopita") -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                any(t, "pause", "arrete", "stop", "simamisha") -> KeyEvent.KEYCODE_MEDIA_PAUSE
                else -> KeyEvent.KEYCODE_MEDIA_PLAY
            }
            mediaKey(c, code)
            say(tr("D'accord.", "Sawa."))
            return
        }

        // ---- Notifications ----
        if (t.contains("notification") || t.contains("arifa")) {
            if (any(t, "automatique", "automatiquement") || (any(t, "active", "desactive") && any(t, "lecture"))) {
                val off = any(t, "desactive", "arrete", "coupe", "stop")
                Store.setFlag(c, "autoread", !off)
                say(tr(if (off) "Lecture automatique des notifications désactivée." else "Je lirai vos notifications à voix haute.", "Sawa."))
                return
            }
            if (any(t, "ouvre", "panneau", "affiche", "baisse")) {
                val a = acc() ?: return
                a.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
                say(tr("Voici vos notifications.", "Hizi hapa arifa zako."))
                return
            }
            val enabled = Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners")
                ?.contains(c.packageName) == true
            if (!enabled) {
                say(tr("Activez d'abord l'accès aux notifications pour Helios depuis son écran principal.", "Washa kwanza ruhusa ya arifa kwa Helios."))
                return
            }
            val l = Store.list(c, "notifs").takeLast(5).reversed()
            say(if (l.isEmpty()) tr("Aucune nouvelle notification.", "Hakuna arifa mpya.") else l.joinToString(" . "))
            return
        }

        // ---- Navigation système (accessibilité) ----
        if (any(t, "en arriere") || words.contains("retour") || words.contains("nyuma")) {
            val a = acc() ?: return
            a.global(AccessibilityService.GLOBAL_ACTION_BACK)
            say(tr("Retour.", "Nyuma."))
            return
        }
        if (any(t, "ecran d'accueil", "page d'accueil", "va a l'accueil") || words.contains("accueil") || words.contains("nyumbani")) {
            val a = acc() ?: return
            a.global(AccessibilityService.GLOBAL_ACTION_HOME)
            say(tr("Accueil.", "Nyumbani."))
            return
        }
        if (any(t, "applications recentes", "apps recentes", "recents", "multitache")) {
            val a = acc() ?: return
            a.global(AccessibilityService.GLOBAL_ACTION_RECENTS)
            say(tr("Applications récentes.", "Programu za hivi karibuni."))
            return
        }
        if (any(t, "parametres rapides")) {
            val a = acc() ?: return
            a.global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
            say(tr("Paramètres rapides.", "Mipangilio ya haraka."))
            return
        }
        if (any(t, "verrouille", "bloque le telephone", "eteins l'ecran", "eteins l ecran")) {
            val a = acc() ?: return
            if (Build.VERSION.SDK_INT >= 28) {
                a.global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
                say(tr("Téléphone verrouillé.", "Simu imefungwa."))
            } else {
                say(tr("Non disponible sur cette version d'Android.", "Haipatikani."))
            }
            return
        }
        if (any(t, "capture d'ecran", "capture ecran", "screenshot")) {
            val a = acc() ?: return
            if (Build.VERSION.SDK_INT >= 28) {
                a.global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
                say(tr("Capture faite.", "Imechukuliwa."))
            } else {
                say(tr("Non disponible sur cette version d'Android.", "Haipatikani."))
            }
            return
        }

        // ---- Défilement ----
        if (any(t, "defile", "scroll", "descends la page", "remonte la page")) {
            val a = acc() ?: return
            val down = !any(t, "haut", "remonte", "juu")
            a.swipe(down)
            return
        }

        // ---- Toucher un élément ----
        val clickRe = Regex("^(?:touche|clique sur|clique|appuie sur|appuie|tape sur|bonyeza)\\s+(?:sur\\s+)?(?:le bouton\\s+|le\\s+|la\\s+|l')?(.+)$")
        val cm = clickRe.find(t)
        if (cm != null) {
            val a = acc() ?: return
            val label = cm.groupValues[1]
            if (a.clickLabel(label)) say(tr("Fait.", "Imefanyika."))
            else say(tr("Je ne vois pas « $label » à l'écran.", "Sioni \"$label\" kwenye skrini."))
            return
        }

        // ---- Appels ----
        if (words.contains("raccroche") || any(t, "termine l'appel", "kata simu")) {
            try {
                val tm = c.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                @Suppress("DEPRECATION")
                val ok = tm.endCall()
                say(if (ok) tr("Appel terminé.", "Simu imekatwa.") else tr("Aucun appel à terminer.", "Hakuna simu."))
            } catch (e: Exception) {
                say(tr("Autorisez la gestion des appels dans l'application.", "Ruhusu usimamizi wa simu."))
            }
            return
        }
        if (words.contains("decroche") || any(t, "reponds a l'appel", "pokea simu")) {
            try {
                val tm = c.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                tm.acceptRingingCall()
                say(tr("Appel décroché.", "Nimepokea."))
            } catch (e: Exception) {
                say(tr("Autorisez la gestion des appels dans l'application.", "Ruhusu usimamizi wa simu."))
            }
            return
        }
        val callRe = Regex("^(?:appelle|appeler|telephone a|passe un appel a|piga simu kwa|piga simu)\\s+(?:a\\s+|au\\s+)?(.+)$")
        val callM = callRe.find(t)
        if (callM != null) {
            val ct = resolve(c, callM.groupValues[1])
            if (ct == null) {
                say(tr("Je ne trouve pas ce contact.", "Sipati mwasiliani huyo."))
                return
            }
            pending = {
                val num = ct.second.filter { it.isDigit() || it == '+' }
                val perm = Act.granted(c, android.Manifest.permission.CALL_PHONE)
                val i = Intent(if (perm) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num)))
                if (!Act.go(c, i)) say(tr("Impossible de lancer l'appel.", "Imeshindikana kupiga."))
            }
            say(tr("J'appelle ${ct.first}. Confirmez ?", "Napiga simu kwa ${ct.first}. Unathibitisha?"))
            return
        }

        // ---- WhatsApp ----
        if (t.contains("whatsapp")) {
            val r1 = Regex("(?i)whatsapp\\s+(?:à|a|au|pour|kwa)\\s+(.+?)\\s+(?:disant|dis|qui dit|que|:)\\s+(.+)")
            val r2 = Regex("(?i)(?:à|a|au|pour)\\s+(.+?)\\s+(?:sur|par)\\s+whatsapp\\s+(?:disant|dis|qui dit|que|:)\\s+(.+)")
            val m = r1.find(raw) ?: r2.find(raw)
            if (m != null) {
                val ct = resolve(c, m.groupValues[1])
                val msg = m.groupValues[2].trim()
                if (ct == null) {
                    say(tr("Je ne trouve pas ce contact.", "Sipati mwasiliani huyo."))
                    return
                }
                pending = {
                    val num = Act.intl(ct.second)
                    val uri = Uri.parse("https://wa.me/$num?text=" + enc(msg))
                    var i = Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp")
                    var ok = Act.go(c, i)
                    if (!ok) {
                        i = Intent(Intent.ACTION_VIEW, uri)
                        ok = Act.go(c, i)
                    }
                    if (ok) {
                        h.postDelayed({
                            val a = HeliosAccess.instance
                            if (a != null && !a.clickLabel("envoyer")) a.clickLabel("send")
                        }, 4500)
                        say(tr("Message WhatsApp envoyé à ${ct.first}.", "Ujumbe wa WhatsApp umetumwa kwa ${ct.first}."))
                    } else {
                        say(tr("WhatsApp n'est pas disponible.", "WhatsApp haipatikani."))
                    }
                }
                say(tr("J'envoie à ${ct.first} sur WhatsApp : $msg. Confirmez ?", "Natuma kwa ${ct.first} kupitia WhatsApp: $msg. Unathibitisha?"))
                return
            }
        }

        // ---- SMS ----
        val smsM = Regex("(?i)(?:sms|message|texto|ujumbe)\\s+(?:à|a|au|pour|kwa)\\s+(.+?)\\s+(?:disant|dis|qui dit|que|:)\\s+(.+)").find(raw)
        if (smsM != null && !t.contains("whatsapp")) {
            val ct = resolve(c, smsM.groupValues[1])
            val msg = smsM.groupValues[2].trim()
            if (ct == null) {
                say(tr("Je ne trouve pas ce contact.", "Sipati mwasiliani huyo."))
                return
            }
            pending = {
                if (!Act.granted(c, android.Manifest.permission.SEND_SMS)) {
                    say(tr("Autorisez l'envoi de SMS dans l'application.", "Ruhusu kutuma SMS."))
                } else {
                    val ok = Act.sms(c, ct.second, msg)
                    say(
                        if (ok) tr("SMS envoyé à ${ct.first}.", "SMS imetumwa kwa ${ct.first}.")
                        else tr("L'envoi du SMS a échoué.", "Kutuma SMS kumeshindikana.")
                    )
                }
            }
            say(tr("J'envoie ce SMS à ${ct.first} : $msg. Confirmez ?", "Natuma SMS kwa ${ct.first}: $msg. Unathibitisha?"))
            return
        }

        // ---- Écrire du texte ----
        val typeM = Regex("(?i)^(?:écris|ecris|tape|andika)\\s+(.+)$").find(raw.trim())
        if (typeM != null) {
            val a = acc() ?: return
            if (a.typeText(typeM.groupValues[1])) say(tr("C'est écrit.", "Nimeandika."))
            else say(tr("Touchez d'abord un champ de texte.", "Gusa kwanza sehemu ya kuandika."))
            return
        }

        // ---- Vision par caméra (hors ligne) ----
        if (any(t, "lis le texte", "lis ce texte", "lis ce document", "lis ce qui est ecrit", "soma maandishi")) {
            say(tr("Je regarde.", "Naangalia."))
            Vision.run(c, any(t, "camera avant", "devant moi"), true, say)
            return
        }
        if (any(t, "que vois tu", "ce que tu vois", "regarde autour", "regarde moi", "regarde devant", "angalia", "unaona nini")) {
            say(tr("Je regarde.", "Naangalia."))
            Vision.run(c, any(t, "regarde moi", "devant moi", "camera avant", "selfie"), false, say)
            return
        }

        // ---- Lire l'écran ----
        if (any(t, "lis l'ecran", "lis ecran", "lis l ecran", "qu'est-ce qu'il y a a l'ecran", "soma skrini")) {
            val a = acc() ?: return
            val s = a.readScreen()
            say(if (s.isBlank()) tr("Je ne vois aucun texte.", "Sioni maandishi.") else s)
            return
        }

        // ---- Minuteur ----
        if (any(t, "minuteur", "chrono", "timer", "muda wa")) {
            val m = Regex("(\\d+)\\s*(secondes?|sec|minutes?|min|heures?|h)\\b").find(t)
            if (m != null) {
                val n = m.groupValues[1].toLong()
                val u = m.groupValues[2]
                val secs = when {
                    u.startsWith("h") -> n * 3600
                    u.startsWith("m") -> n * 60
                    else -> n
                }
                val i = Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, secs.toInt())
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "Helios")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                say(if (Act.go(c, i)) tr("Minuteur lancé.", "Kipima muda kimeanza.") else tr("Impossible de lancer le minuteur.", "Imeshindikana."))
                return
            }
        }

        // ---- Alarme ----
        if (any(t, "alarme", "reveille", "reveil", "kengele")) {
            val m = Regex("(\\d{1,2})\\s*(?:h|heures?|:)?\\s*(\\d{2})?").find(t)
            if (m != null) {
                var hh = m.groupValues[1].toInt()
                val mi = if (m.groupValues[2].isNotEmpty()) m.groupValues[2].toInt() else 0
                if (any(t, "soir", "apres midi") && hh < 12) hh += 12
                if (hh in 0..23 && mi in 0..59) {
                    val i = Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, hh)
                        .putExtra(AlarmClock.EXTRA_MINUTES, mi)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, "Helios")
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    val hs = hh.toString().padStart(2, '0') + ":" + mi.toString().padStart(2, '0')
                    say(
                        if (Act.go(c, i)) tr("Alarme réglée à $hs.", "Kengele imewekwa saa $hs.")
                        else tr("Impossible de régler l'alarme.", "Imeshindikana kuweka kengele.")
                    )
                    return
                }
            }
        }

        // ---- Rappel ----
        val remM = Regex("(?i)rappelle[- ]moi\\s+(?:de\\s+|d['’]|que\\s+)?(.+?)\\s+dans\\s+(\\d+)\\s*(secondes?|minutes?|min|heures?|h)\\b").find(raw)
        if (remM != null) {
            val txt = remM.groupValues[1].trim()
            val n = remM.groupValues[2].toLong()
            val u = remM.groupValues[3].lowercase()
            val ms = when {
                u.startsWith("h") -> n * 3600000L
                u.startsWith("m") -> n * 60000L
                else -> n * 1000L
            }
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val ri = Intent(c, ReminderReceiver::class.java).putExtra("text", txt)
            val pi = PendingIntent.getBroadcast(
                c, (System.currentTimeMillis() % 100000).toInt(), ri,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + ms, pi)
            say(tr("Je vous le rappellerai dans $n ${remM.groupValues[3]}.", "Nitakukumbusha baada ya $n ${remM.groupValues[3]}."))
            return
        }

        // ---- Notes et tâches ----
        if (any(t, "mes notes", "lis les notes", "noti zangu")) {
            val l = Store.list(c, "notes")
            say(if (l.isEmpty()) tr("Vous n'avez aucune note.", "Huna noti.") else l.takeLast(8).joinToString(" . "))
            return
        }
        if (any(t, "mes taches", "liste des taches")) {
            val l = Store.list(c, "tasks")
            say(if (l.isEmpty()) tr("Aucune tâche en attente.", "Hakuna kazi.") else l.takeLast(8).joinToString(" . "))
            return
        }
        if (any(t, "efface", "supprime", "vide") && (t.contains("notes") || t.contains("taches"))) {
            val key = if (t.contains("notes")) "notes" else "tasks"
            pending = {
                Store.saveList(c, key, emptyList())
                say(tr("C'est effacé.", "Imefutwa."))
            }
            say(tr("Voulez-vous vraiment tout effacer ?", "Unataka kufuta kila kitu?"))
            return
        }
        val taskM = Regex("(?i)(?:ajoute une tâche|ajoute une tache|nouvelle tâche|nouvelle tache)\\s*:?\\s*(.+)").find(raw)
        if (taskM != null) {
            Store.add(c, "tasks", taskM.groupValues[1].trim())
            say(tr("Tâche ajoutée.", "Kazi imeongezwa."))
            return
        }
        val noteM = Regex("(?i)(?:prends? en note|ajoute une note|^note)\\s*:?\\s*(.+)").find(raw.trim())
        if (noteM != null) {
            Store.add(c, "notes", noteM.groupValues[1].trim())
            say(tr("Note enregistrée.", "Noti imehifadhiwa."))
            return
        }

        // ---- Calcul (hors ligne) ----
        if (any(t, "calcule", "combien font", "combien fait", "hesabu")) {
            var e = t.replace("multiplie par", " * ").replace("divise par", " / ")
                .replace("plus", " + ").replace("moins", " - ").replace("fois", " * ")
                .replace("virgule", ".")
            e = e.replace(" ", "").replace(Regex("[^0-9+\\-*/().]"), "")
            try {
                val v = Calc(e).parse()
                if (v.isNaN() || v.isInfinite()) throw IllegalArgumentException()
                val r = if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString() else String.format(Locale.US, "%.2f", v)
                say(tr("Le résultat est $r.", "Jibu ni $r."))
            } catch (ex: Exception) {
                say(tr("Je n'ai pas pu faire ce calcul.", "Sikuweza kukokotoa."))
            }
            return
        }

        // ---- Internet (uniquement si connecté) ----
        val needNet = tr(
            "Il n'y a pas de connexion internet. Je ferai cela dès que vous serez en ligne.",
            "Hakuna mtandao. Nitafanya hivyo ukiwa mtandaoni."
        )
        val ytM = Regex("(?:cherche|joue|mets|regarde)\\s+(.+?)\\s+sur youtube").find(t)
        if (ytM != null) {
            if (!Act.online(c)) { say(needNet); return }
            Act.go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + enc(ytM.groupValues[1]))))
            say(tr("Je cherche sur YouTube.", "Natafuta YouTube."))
            return
        }
        if (any(t, "meteo", "hali ya hewa")) {
            if (!Act.online(c)) { say(needNet); return }
            Act.go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + enc("météo"))))
            say(tr("Voici la météo.", "Hii hapa hali ya hewa."))
            return
        }
        if (any(t, "actualites", "infos du jour", "habari za leo")) {
            if (!Act.online(c)) { say(needNet); return }
            Act.go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://news.google.com")))
            say(tr("Voici les actualités.", "Hizi hapa habari."))
            return
        }
        val navM = Regex("^(?:itineraire|navigue|navigation|emmene moi|conduis moi|guide moi)\\s*(?:pour|vers|a|au|jusqu a|jusqu'a)?\\s+(.+)$").find(t)
        if (navM != null) {
            val dest = navM.groupValues[1]
            var i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + enc(dest))).setPackage("com.google.android.apps.maps")
            if (!Act.go(c, i)) {
                i = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + enc(dest)))
                Act.go(c, i)
            }
            say(tr("Itinéraire vers $dest. La carte a besoin d'internet sauf si vous avez téléchargé la zone hors ligne.", "Njia kuelekea $dest."))
            return
        }
        val trM = Regex("(?i)traduis(?:\\s+en\\s+(\\p{L}+))?\\s+(.+)").find(raw)
        if (trM != null) {
            val offline = Phrases.translate(trM.groupValues[1], trM.groupValues[2])
            if (offline != null) { say(offline); return }
            if (!Act.online(c)) {
                say(tr("Je ne connais pas cette phrase hors ligne. Je sais traduire les mots courants français et swahili sans internet.", needNet))
                return
            }
            val lg = when (Act.norm(trM.groupValues[1])) {
                "francais" -> "fr"
                "swahili" -> "sw"
                "lingala" -> "ln"
                "espagnol" -> "es"
                "" -> "en"
                else -> "en"
            }
            Act.go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://translate.google.com/?sl=auto&tl=$lg&text=" + enc(trM.groupValues[2]) + "&op=translate")))
            say(tr("Voici la traduction.", "Hii hapa tafsiri."))
            return
        }
        val searchM = Regex("(?i)\\b(?:cherche|recherche|tafuta)\\s+(?:sur internet\\s+|sur google\\s+|sur le web\\s+)?(.+)").find(raw)
        if (searchM != null) {
            if (!Act.online(c)) { say(needNet); return }
            Act.go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + enc(searchM.groupValues[1]))))
            say(tr("Je cherche.", "Natafuta."))
            return
        }

        // ---- Réglages Android ----
        if (any(t, "wifi", "wi-fi", "donnees mobiles", "bluetooth", "mode avion", "localisation", "gps", "luminosite", "economie d'energie", "parametres")) {
            val i: Intent = when {
                any(t, "wifi", "wi-fi", "donnees mobiles") ->
                    if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
                    else Intent(Settings.ACTION_WIFI_SETTINGS)
                t.contains("bluetooth") -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                t.contains("avion") -> Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
                any(t, "localisation", "gps") -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                t.contains("luminosite") -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
                t.contains("economie") -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
                else -> Intent(Settings.ACTION_SETTINGS)
            }
            Act.go(c, i)
            say(tr("Voici le réglage. Android n'autorise plus les applications à basculer cet interrupteur directement ; dites « touche » suivi du nom pour que je le fasse.", "Hii hapa mipangilio."))
            return
        }

        // ---- Désinstaller ----
        val unM = Regex("^(?:desinstalle|supprime l'application|supprime l'appli|ondoa programu)\\s+(.+)$").find(t)
        if (unM != null) {
            val app = Act.findApp(c, unM.groupValues[1])
            if (app == null) {
                say(tr("Je ne trouve pas cette application.", "Sipati programu hiyo."))
                return
            }
            pending = {
                Act.go(c, Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.second)))
            }
            say(tr("Désinstaller ${app.first} ? Confirmez.", "Kuondoa ${app.first}? Thibitisha."))
            return
        }

        // ---- Caméra ----
        if (any(t, "appareil photo", "camera", "prends une photo", "prends moi en photo", "piga picha")) {
            Act.go(c, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            if (any(t, "prends", "piga")) {
                h.postDelayed({
                    val a = HeliosAccess.instance
                    if (a != null) {
                        if (!a.clickLabel("obturateur")) if (!a.clickLabel("shutter")) a.clickLabel("prendre une photo")
                    }
                }, 3000)
            }
            say(tr("J'ouvre l'appareil photo.", "Nafungua kamera."))
            return
        }

        // ---- Ouvrir une application ----
        val openM = Regex("^(?:ouvre|ouvrir|lance|lancer|demarre|demarrer|fungua)\\s+(?:l'application |l'appli |application |appli |programme |le |la |les |l')?(.+)$").find(t)
        if (openM != null) {
            val q = openM.groupValues[1]
            val app = Act.findApp(c, q)
            if (app != null) {
                val i = c.packageManager.getLaunchIntentForPackage(app.second)
                if (i != null && Act.go(c, i)) {
                    say(tr("J'ouvre ${app.first}.", "Nafungua ${app.first}."))
                    return
                }
            }
            if (q.contains(".") && Act.online(c)) {
                val url = if (q.startsWith("http")) q else "https://" + q.replace(" ", "")
                Act.go(c, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                say(tr("J'ouvre le site.", "Nafungua tovuti."))
                return
            }
            say(tr("Je ne trouve pas l'application « $q ».", "Sipati programu \"$q\"."))
            return
        }

        // ---- Conversation hors ligne ----
        if (any(t, "bonjour", "salut", "hello", "jambo", "hujambo", "bonsoir")) {
            say(tr("Bonjour ! Que puis-je faire pour vous ?", "Jambo! Naweza kukusaidia nini?"))
            return
        }
        if (any(t, "merci", "asante")) {
            say(tr("Avec plaisir.", "Karibu."))
            return
        }
        if (any(t, "comment vas", "unaendeleaje", "habari yako")) {
            say(tr("Tous mes systèmes fonctionnent parfaitement.", "Mifumo yangu yote inafanya kazi vizuri."))
            return
        }
        if (any(t, "qui es tu", "tu es qui", "ton nom", "wewe ni nani")) {
            say(tr("Je suis HELIOS, votre assistant vocal. Je fonctionne hors ligne et j'utilise internet seulement quand il est disponible.", "Mimi ni HELIOS, msaidizi wako wa sauti."))
            return
        }
        if (any(t, "blague", "mzaha")) {
            val jokes = listOf(
                "Pourquoi les programmeurs confondent Halloween et Noël ? Parce que trente et un octobre égale vingt-cinq décembre.",
                "Un bug, c'est une fonctionnalité qu'on n'a pas encore documentée.",
                "Il y a dix sortes de personnes : celles qui comprennent le binaire et les autres."
            )
            say(jokes.random())
            return
        }
        if (any(t, "bonne nuit", "usiku mwema")) {
            say(tr("Bonne nuit. Je reste à l'écoute si vous avez besoin de moi.", "Usiku mwema."))
            return
        }

        // Dernier recours : corriger les mots de commande mal prononcés puis réessayer une fois.
        if (!retrying) {
            val fx = Fuzzy.fix(t)
            if (fx != t) {
                retrying = true
                try {
                    handle(c, fx, say)
                } finally {
                    retrying = false
                }
                return
            }
        }

        say(
            tr(
                "Je n'ai pas compris : $raw. Dites « que peux-tu faire » pour la liste de mes commandes.",
                "Sijaelewa: $raw. Sema \"unaweza kufanya nini\" kwa orodha ya amri."
            )
        )
    }
}
